#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include "SNAPhash.h"
#include "SNAP.h"

//SNAP hashtable

struct SNAPnode {
   SNAP data;
   int key;
   struct SNAPnode* next;
};

struct SNAPhash{
   SNAPNode* hashArray;
   int size;
};

SNAPHash new_snaphash(int size){
   SNAPHash newhash=(SNAPHash)malloc(sizeof(struct SNAPhash));
   newhash->hashArray=(SNAPNode*)calloc(size,sizeof(SNAPNode));
   newhash->size=size;
   for(int i=0;i<size;i++){
     newhash->hashArray[i]=NULL;
   }

   return newhash;
}

bool existSNAP(SNAP data,SNAPHash hash){

   int hashIndex=(data->StudentId) % (hash->size);
   SNAPNode first=hash->hashArray[hashIndex];
   for(SNAPNode n=first;n!=NULL;n=n->next){
      if(n->data->StudentId==data->StudentId && n->data->Name==data->Name && n->data->Address==data->Address && n->data->Phone==data->Phone){
          return true;
      }
   }
   return false;
}


void insertSNAP(SNAP data,SNAPHash hash) {
  if(existSNAP(data,hash)){
    printf("%s\n","already exist");
  }else{
   SNAPNode newnode = (SNAPNode) malloc(sizeof(struct SNAPnode));

   newnode->data = data;
   newnode->key = data->StudentId;
   newnode->next=NULL;

   int hashIndex = (data->StudentId) % (hash->size);

   SNAPNode first=hash->hashArray[hashIndex];
   if (first==NULL){
      hash->hashArray[hashIndex]=newnode;
   }else if(first!=NULL){

     hash->hashArray[hashIndex]=newnode;
     newnode->next=first;
   }
 }
}

SNAPNode SNAPlookup(char* studentId,char* name,char* address,char* phone,SNAPHash hash){
   SNAPNode selected=(SNAPNode)malloc(sizeof(struct SNAPnode));
   selected->key=0;
   int hashIndex=-1;
   int key;
   if(strcmp(studentId,"*")!=0){
     key=atoi(studentId);
     hashIndex=key%(hash->size);
   }
   if(hashIndex!=-1){
    SNAPNode n=hash->hashArray[hashIndex];
   //printf("key: %d\n",n->key);
   while(n!=NULL){
     //printf("%s\n",course);
     //printf("%s\n",n->data->Course);
     if(strcmp(n->data->Name, name)==0){
       //printf("%s\n","yes");
       if(selected->key==0){
         //printf("%s\n","yes");
         selected->data=n->data;
         selected->key=n->key;
       }
       else if(selected->key!=0){
         SNAPNode ff=n;
         ff->next=selected;
         selected=ff;
       }
     }
     n=n->next;
   }
 }else if(strcmp(name,"*")!=0){
     for(int i=0;i<hash->size;i++){
        SNAPNode snode=hash->hashArray[i];
        while(snode!=NULL){
          if(strcmp(snode->data->Name,name)==0){
            selected->data=snode->data;
            selected->key=snode->key;
          }
          snode=snode->next;
        }
     }
 }
   return selected;
}

void print_SNAPnode(SNAPNode node){
  printf("%d",(node)->data->StudentId);
  printf("/%s",(node)->data->Name);
  printf("/%s/",(node)->data->Address);
  printf("%d",(node)->data->Phone);
  //printf("%s\n"," ");
}

void print_SNAPlist(SNAPNode first){
   while(first!=NULL){
     printf("%d",first->data->StudentId);
     printf("/%s/",first->data->Name);
     printf("%s/",first->data->Address);
     printf("%d",first->data->Phone);
     printf("%s"," ");
     first=first->next;
   }
}

void displaySNAP(SNAPHash hash) {

    for (int i = 0; i < hash->size; i++) {

        print_SNAPlist(hash->hashArray[i]);
        printf("%s\n"," ");
    }
}
