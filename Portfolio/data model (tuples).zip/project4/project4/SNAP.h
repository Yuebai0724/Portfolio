#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

struct snap {
   int StudentId;
   char Name[15];
   char Address[20];
   int Phone;
};

typedef struct snap* SNAP;

SNAP new_SNAP(int StudentId,char* Name,char* Address, int Phone);
