#include "SNAP.h"

struct snap {
   int StudentId;
   char Name[15];
   char Address[20];
   int Phone;
};

SNAP new_SNAP(int StudentId,char* Name,char* Address, int Phone){
   SNAP newSNAP=(SNAP)malloc(sizeof(struct snap));
   newSNAP->StudentId=StudentId;
   strcpy(newSNAP->Name,Name);
   strcpy(newSNAP->Address,Address);
   newSNAP->Phone=Phone;

   return newSNAP;
}
