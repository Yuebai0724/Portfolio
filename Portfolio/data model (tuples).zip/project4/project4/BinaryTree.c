
#include "BinaryTree.h"

struct Node{
    char* value;
    tree_node* left;
    tree_node* right;
    Node ndata;
};

tree_node* createNode (char* value){
    tree_node* newNode = (tree_node*) malloc (sizeof(tree_node));
    // if (newNode == NULL){
    //     fprintf (stderr, "Out of memory!!! (create_node)\n");
    //     exit(1);
    // }
    newNode->value = value;
    newNode->left = NULL;
    newNode->right = NULL;
    return newNode;
}

void insertTree (tree_node* root,char* value){

    int is_left = 0;
    tree_node* curr = root;
    tree_node* prev = NULL;
    if(root == NULL){
        root = createNode (value);
    }else{
        while (curr != NULL){
            if(strcmp(value,curr->value)<0){
                prev = curr;
                curr = curr->left;
                is_left = 1;
            }else if (strcmp(value,curr->value)>0){
                prev = curr;
                curr = curr->right;
                is_left = 0;
            }
        }
        if(is_left){
            prev->left = createNode (value);
        }else{
            prev->right = createNode (value);
        }

    }

}

void printTree (tree_node *root){
    if(root == NULL){
        return;
    }else{
        printTree (root->left);
        printf("%s\n", root->value);
        printTree (root->right);
    }
}
