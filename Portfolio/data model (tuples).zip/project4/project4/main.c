
#include "hashtest.c" //the hashtable structure for CSG relation
#include "SNAPhash.c" //the hashtable structure for SNAP relation
#include "CRhash.c" //the hashtable structure for CR relation

//#include "BinaryTree.c"


int main(int argc, char **argv) {
//part 1
   Hash CSGhash=new_hash(10);

   char course1[6]="CS101";
   char course2[6]="EE200";
   char course3[6]="PH100";
   int StudentId1=12345;
   int StudentId2=67890;
   int StudentId3=22222;
   int StudentId4=33333;
   char grade1[3]="A";
   char grade2[3]="B";
   char grade3[3]="C";
   char grade4[3]="B+";
   char grade5[3]="A-";
   char grade6[3]="C+";

   CSG tuple1=new_CSG(course1,StudentId1,grade1);
   CSG tuple2=new_CSG(course1,StudentId2,grade2);
   CSG tuple3=new_CSG(course2,StudentId1,grade3);
   CSG tuple4=new_CSG(course2,StudentId3,grade4);
   CSG tuple5=new_CSG(course1,StudentId4,grade5);
   CSG tuple6=new_CSG(course3,StudentId2,grade6);

   insert(tuple1,CSGhash);
   insert(tuple2,CSGhash);
   insert(tuple3,CSGhash);
   insert(tuple4,CSGhash);
   insert(tuple5,CSGhash);
   insert(tuple6,CSGhash);
   insert(tuple6,CSGhash);
   //printf("%s\n","The CSG relation:");
   //display(CSGhash);
/*
   Node selected=lookup("CS101","12345","*",CSGhash);
   printf("%s\n","a). lookup('CSC101', 12345, *)");
   print_node(selected);
   printf("%s\n"," ");
*/

   char name1[15]="C. Brown";
   char name2[15]="L. Van Pelt";
   char name3[15]="P. Patty";
   char address1[20]="12 Apple St.";
   char address2[20]="34 Pear Ave.";
   char address3[20]="56 Grape Blvd.";
   int phone1=5551234;
   int phone2=5555678;
   int phone3=5559999;
   SNAP tuple11=new_SNAP(StudentId1,name1,address1,phone1);
   SNAP tuple12=new_SNAP(StudentId2,name2,address2,phone2);
   SNAP tuple13=new_SNAP(StudentId3,name3,address3,phone3);

   SNAPHash snaphash=new_snaphash(10);
   insertSNAP(tuple11,snaphash);
   insertSNAP(tuple12,snaphash);
   insertSNAP(tuple13,snaphash);
   insertSNAP(tuple13,snaphash);
   //printf("%s\n","The SNAP relation:");
   //displaySNAP(snaphash);



   CRHash crhash=new_crhash(4);
   char room1[15]="Turing Aud.";
   char room2[15]="25 Ohm Hall";
   char room3[15]="Newton Lab.";
   CR tuple41=new_CR(course1,room1);
   CR tuple42=new_CR(course2,room2);
   CR tuple43=new_CR(course3,room3);
   insertCR(tuple41,crhash);
   insertCR(tuple42,crhash);
   insertCR(tuple43,crhash);
   insertCR(tuple43,crhash);
   //deleteCR("CS101","*",crhash);
   //printf("%s\n","The CR relation:");
   //displayCR(crhash);

//part 2
   char inputName[15]="C. Brown";
   char inputCourse[6]="CS101";
   /*
   printf("%s\n", "Enter student name:");
   scanf("%s", inputName);
   printf("%s\n", "Enter course name:");
   scanf("%s", inputCourse);
   */
   printf("What grade did %s",inputName);
   printf(" get in %s?\n",inputCourse);
   SNAPNode selected1=SNAPlookup("*",inputName,"*","*",snaphash);
   print_SNAPnode(selected1);
   printf("%s\n","");
   int studentId=selected1->key;
   char Idstring[6];
   sprintf(Idstring,"%d",studentId);
   //printf("IDstring: %s\n",Idstring);

   Node selected2=lookup("CS101","12345","*",CSGhash);
   print_node(selected2);
   printf("%s\n","");

   printf("%s get ",inputName);
   printf("%s in this course\n",selected2->data->Grade);

   return 0;
}
