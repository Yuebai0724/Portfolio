#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef struct csg *CSG;
typedef struct tuple* Tuple;
Tuple new_Tuple(char* course,char* studentId, char* grade);
CSG new_CSG(char* course, int StudentId, char* Grade);

void print_tuple(CSG tuple);
