#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
typedef struct cr* CR;

CR new_CR(char* Course,char* Room);
