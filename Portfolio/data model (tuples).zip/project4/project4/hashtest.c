#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include "hashtest.h"

//csg hashtable

struct node {
   CSG data;
   int key;
   struct node* next;
};

struct hash{
   Node* hashArray;
   int size;
};

Hash new_hash(int size){
   Hash newhash=(Hash)malloc(sizeof(struct hash));
   newhash->hashArray=(Node*)calloc(size,sizeof(Node));
   newhash->size=size;
   for(int i=0;i<size;i++){
     newhash->hashArray[i]=NULL;
   }

   return newhash;
}

bool exist(CSG data,Hash hash){

   int hashIndex=(data->StudentId) % (hash->size);
   Node first=hash->hashArray[hashIndex];
   for(Node n=first;n!=NULL;n=n->next){
      if(n->data->StudentId==data->StudentId && n->data->Course==data->Course && n->data->Grade==data->Grade){
          return true;
      }
   }
   return false;
}


void insert(CSG data,Hash hash) {
if(exist(data,hash)){
  printf("%s\n","already exist");
}else{
   Node newnode = (Node) malloc(sizeof(struct node));

   newnode->data = data;
   newnode->key = data->StudentId;
   newnode->next=NULL;

   int hashIndex = (data->StudentId) % (hash->size);

   Node first=hash->hashArray[hashIndex];
   if (first==NULL){
      hash->hashArray[hashIndex]=newnode;
   }else if(first!=NULL){

     hash->hashArray[hashIndex]=newnode;
     newnode->next=first;
   }
}
}

Node lookup(char* course,char* studentId,char* grade,Hash hash){
   Node selected=(Node)malloc(sizeof(struct node));
   selected->key=0;
   int hashIndex;
   int key;
   if(strcmp(studentId,"*")!=0){
     key=atoi(studentId);
     hashIndex=key%(hash->size);
   }

   Node n=hash->hashArray[hashIndex];
   //printf("key: %d\n",n->key);
   while(n!=NULL){
     //printf("%s\n",course);
     //printf("%s\n",n->data->Course);
     if(strcmp(n->data->Course, course)==0){
       //printf("%s\n","yes");
       if(selected->key==0){
         //printf("%s\n","yes");
         selected->data=n->data;
         selected->key=n->key;
       }
       else if(selected->key!=0){
         Node ff=n;
         ff->next=selected;
         selected=ff;
       }
     }
     n=n->next;
   }
   return selected;
}

/*
void delete(char* course,char* studentId,char* grade){

}
*/
void print_node(Node node){
  printf("%s/",(node)->data->Course);
  printf("%d",(node)->data->StudentId);
  printf("/%s",(node)->data->Grade);
  //printf("%s\n"," ");
}

void print_list(Node first){
   while(first!=NULL){
     print_node(first);
     printf("%s"," ");
     first=first->next;
   }
}


void display(Hash hash) {

    for (int i = 0; i < hash->size; i++) {
        print_list(hash->hashArray[i]);
        printf("%s\n"," ");
    }
}
