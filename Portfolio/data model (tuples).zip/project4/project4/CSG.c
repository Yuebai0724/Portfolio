#include "CSG.h"


struct csg {
   char Course[6];
   int StudentId;
   char Grade[3];
};

struct tuple{
   char course[6];
   char studentId[6];
   char grade[3];
};

Tuple new_Tuple(char* course,char* studentId, char* grade){
  Tuple newTuple=(Tuple)malloc(sizeof(struct tuple));
  strcpy(newTuple->course,course);
  strcpy(newTuple->studentId,studentId);
  strcpy(newTuple->grade,grade);
  return newTuple;
}

CSG new_CSG(char* course, int StudentId, char* Grade){
   CSG newCSG=(CSG)malloc(sizeof(struct csg));
   newCSG->StudentId=StudentId;
   strcpy(newCSG->Course,course);
   strcpy(newCSG->Grade,Grade);
   return newCSG;
}

void print_tuple(CSG tuple){
   printf("%s/",tuple->Course);
   printf("%d",tuple->StudentId);
   printf("/%s",tuple->Grade);
}
