#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#ifndef TREE_H
#define TREE_H

typedef struct Node tree_node;


tree_node* createNode (char* value);

void insertTree (tree_node* node,char* value);

void printTree (tree_node *node);

int get_node_count (tree_node *node);

void delete_Tree (tree_node *node);


#endif
