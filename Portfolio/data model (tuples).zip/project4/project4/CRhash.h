#include "CR.c"

typedef struct CRnode* CRNode;
typedef struct CRhash* CRHash;
CRHash new_crhash(int size);
int string_to_int(char* string);
bool existCR(CR data,CRHash hash);

void insertCR(CR data,CRHash hash);

void deleteCR(char* course, char* room, CRHash hash);

void print_CRlist(CRNode first);
void displayCR(CRHash hash);
