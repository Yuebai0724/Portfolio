#include "CSG.c"

typedef struct node* Node;
typedef struct hash* Hash;
Hash new_hash(int size);

bool exist(CSG data,Hash hash);
void insert(CSG data,Hash hash);
Node lookup(char* course,char* studentId,char* grade,Hash hash);
void print_node(Node node);
void print_list(Node first);

void display(Hash hash);
