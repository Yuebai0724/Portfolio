#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include "CRhash.h"

//CR hashtable

struct CRnode {
   CR data;
   int key;
   struct CRnode* next;
};

struct CRhash{
   CRNode* hashArray;
   int size;
};

CRHash new_crhash(int size){
   CRHash newhash=(CRHash)malloc(sizeof(struct CRhash));
   newhash->hashArray=(CRNode*)calloc(size,sizeof(CRNode));
   newhash->size=size;
   for(int i=0;i<size;i++){
     newhash->hashArray[i]=NULL;
   }

   return newhash;
}


int string_to_int(char* string){
  char c=string[0];
  int number=0;
  while (c!=0){
    number=number+c;
    c++;
  }
  //printf("num: %d\n",number);
  return (-number);
}

bool existCR(CR data,CRHash hash){
   int num=string_to_int(data->Course);
   int hashIndex=(num) % (hash->size);
   CRNode first=hash->hashArray[hashIndex];
   for(CRNode n=first;n!=NULL;n=n->next){
      if(n->data->Course==data->Course && n->data->Room==data->Room){
          return true;
      }
   }
   return false;
}


void insertCR(CR data,CRHash hash) {
if(!existCR(data,hash)){
   CRNode newnode = (CRNode) malloc(sizeof(struct CRnode));

   newnode->data = data;
   newnode->key = string_to_int(data->Course);
   newnode->next=NULL;

   int hashIndex = (newnode->key) % (hash->size);

   CRNode first=hash->hashArray[hashIndex];
   if (first==NULL){
      hash->hashArray[hashIndex]=newnode;
   }else if(first!=NULL){

     hash->hashArray[hashIndex]=newnode;
     newnode->next=first;
   }
 }else{
   printf("%s\n","alreay exist");
 }
}

void deleteCR(char* course, char* room, CRHash hash){
  int key;
  int hashIndex=-1;
  if(strcmp(course,"*")!=0){
    key=string_to_int(course);
    hashIndex=key%(hash->size);
  }
  if(strcmp(room,"*")==0){
     hash->hashArray[hashIndex]=NULL;
  }else if(strcmp(room,"*")!=0){
    CRNode n=hash->hashArray[hashIndex];
    while(n!=NULL){
      if(strcmp(n->data->Room,room)==0){
        n=NULL;
      }
      n=n->next;
    }
  }
}

void print_CRlist(CRNode first){
   while(first!=NULL){

     printf("%s/",first->data->Course);
     printf("%s",first->data->Room);
     printf("%s"," ");
     first=first->next;
   }
}

void displayCR(CRHash hash) {

    for (int i = 0; i < hash->size; i++) {

        print_CRlist(hash->hashArray[i]);
        printf("%s\n"," ");
    }
}
