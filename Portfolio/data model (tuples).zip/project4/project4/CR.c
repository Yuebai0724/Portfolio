#include "CR.h"
struct cr {
   char Course[6];
   char Room[15];

};

CR new_CR(char* Course,char* Room){
   CR newCR=(CR)malloc(sizeof(struct cr));

   strcpy(newCR->Course,Course);
   strcpy(newCR->Room,Room);


   return newCR;
}
