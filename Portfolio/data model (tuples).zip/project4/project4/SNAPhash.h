#include "SNAP.h"


typedef struct SNAPnode* SNAPNode;
typedef struct SNAPhash* SNAPHash;
SNAPHash new_snaphash(int size);
bool existSNAP(SNAP data,SNAPHash hash);
void insertSNAP(SNAP data,SNAPHash hash);

SNAPNode SNAPlookup(char* studentId,char* name,char* address,char* phone,SNAPHash hash);
void print_SNAPnode(SNAPNode node);
void print_SNAPlist(SNAPNode first);
void displaySNAP(SNAPHash hash);
