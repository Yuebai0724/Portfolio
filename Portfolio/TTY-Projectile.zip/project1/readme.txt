NAME: Yuebai Gao
net ID: ygao41
UR email: ygao41@u.rochester.edu
I did not collaborate with anyone on this assignment.

In this project, I try to get extra credits by adding some additional randomness into the 
computer's output and having the wall moving towards the user at relatively slow speed. 