
package project1;
import java.util.*;
public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     
		System.out.println("This is a game about guessing speed and angle, checking whether the projectile can pass the wall. ");
		
		int point=10;
		System.out.println("initial point = "+ point);
		
		
		while(point>=0){//The user can't play anymore if his point is below 0.
			Scanner input=new Scanner(System.in);
			System.out.println("Please enter 1 if you want to play; enter 0 to quit.");
			int e = input.nextInt();//ask the user to decide whether to continue(enter 1) the game or not(enter 0)
			
		      if (e==1) {
		       
		       Random ran =new Random();
		       double height = 0+(10-0)*ran.nextDouble();  //get a height randomly from 0 to 10
		       double distance=0+(10-0)*ran.nextDouble(); //get a distance randomly from 0 to 10
		       double spdwall = 0+(1-0)*ran.nextDouble();//get a velocity of the wall moving towards the launcher randomly from 0 to 1 
		       
		       
		       Scanner scan=new Scanner(System.in);
		       System.out.print("Please enter the speed: ");
		       double speed =scan.nextDouble();
		       System.out.print("Please enter the angle: ");
		       double angle =scan.nextDouble();
		
		       double x = distance-spdwall*distance/(speed*Math.cos(angle/180*Math.PI)+spdwall);
		       //calculate the distance when the wall is moving with the speed "spdwall"
		       
		       double i=x*Math.tan(angle/180*Math.PI)-9.8*x*x/2/Math.pow((speed*Math.cos(angle/180*Math.PI)),2);
		       // calculate the height of the projectile when it reaches the wall
		
		
		       int c;
		
		            if(0<=i-height && i-height<=3){
		            	point--; //each launch costs one point.
			            c = 1 + ran.nextInt(3);
			            switch(c){
			            case 1:System.out.println("You made it!");
			            break;
			            case 2:System.out.println("Great job!");
			            break;
			            case 3:System.out.println("Fantastic!");
			            break;
			            }
			
			            point+=5;
			            System.out.println("Your point is:"+point);
		            }
		
		            else if(i-height>3){
		            	point--; //each launch costs one point
			            c = 1 + ran.nextInt(3);
			            switch(c){
			            case 1:System.out.println("Plenty of room");
			            break;
			            case 2:System.out.println("You are going too far!");
			            break;
			            case 3:System.out.println("Please try smaller velocity!");
			            break;
			            }
			            point+=2;
			            System.out.println("Your point is:"+point);
		           }
		            
		           else if(i-height<0 && -3<=i-height){
		        	    point--;//each launch costs 1 point
		        	    c = 1 + ran.nextInt(3);
			            switch(c){
			            case 1:System.out.println("Not quite over.");
			            break;
			            case 2:System.out.println("Try a slightly bigger velocity.");
			            break;
			            case 3:System.out.println("Unlucky!");
			            break;
			            }
			            
			            point-=1;//a near miss loses 1 point
			            System.out.println("Your point is:"+point);
		           }
		
		            else if(i-height<-3){
		            	point--;//each launch costs 1 point
		            	  c = 1 + ran.nextInt(3);
				          switch(c){
				          case 1:System.out.println("Not even close.");
				          break;
				          case 2:System.out.println("You need to try harder!");
				          break;
				          case 3:System.out.println("Try a much bigger velocity!");
				          break;
			           
			             
		                 }
				          point-=3;
				          System.out.println("Your point is:"+point);
		             }}
		   else if(e==0){
			   System.out.println("Thank you for playing!");
			   System.out.println("Your total point is: "+point);//when user chooses to quit the game, his final point is printed.
			   break;
		   }
		}
		      
	  }
		
		
	}	
		
	



