Name: Yuebai Gao
Net ID: 29855315
Assignment number: 1
Lab section: MW 2:00-3:15 pm

In this project, I did the extra credit for the two launches fire against
each other.
Besides, I also made the ground. I add how when the projectile hit the 
ground before it is time for it to explode, it will just explode on
the ground.
Also, if the explosion is outside the screen, it will inform you about that.
At that time, just widen the screen and click "apply" again. You will be
able to see the explosion.

For the explosion type, I made 5 types. I also contain randomness in
the pattern.

When the two fireworks hit each other, a bunch of "hit!!!" would 
appear on the screen.

I hope you will like the pattern that I designed...