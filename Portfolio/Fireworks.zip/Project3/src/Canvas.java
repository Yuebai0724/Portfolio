import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.Timer;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class Canvas extends JComponent implements ActionListener{
	
	private static String m="";
    private static String n="";
	
    protected int x;
    protected int y;
    protected int t=15;
	
	protected double anglevalue;
	protected double speedvalue;
    
	static JButton apply =new JButton("apply");
	
    static JTextField angle=new JTextField(10);
    static JTextField speed=new JTextField(10);
    static JTextField explosion =new JTextField(10);
    static JSlider time=new JSlider(0,30,15);
    static JLabel label6=new JLabel("15");
    Color mycolor;
    
    int times1=0,times2=0,times3=0,times4=0;
    
    static JCheckBox color1=new JCheckBox("red");
    static JCheckBox color2=new JCheckBox("blue");
    static JCheckBox color3=new JCheckBox("green");
    static JCheckBox color4=new JCheckBox("yellow");
   
    static Canvas canvas2=new Canvas();
    
    int x1,x2,y1,y2,x3,y3,x4,y4,x5,y5,x6,y6;
    
	public Canvas(){
		angle.addActionListener(this);
		speed.addActionListener(this);
		apply.addActionListener(this);
		
		setLayout(new FlowLayout());
		
        
		color1.addItemListener(new ItemListener(){
			@Override
			public void itemStateChanged(ItemEvent arg0) {
				// TODO Auto-generated method stub
                times1++;
				if(times1%2!=0){
					mycolor=Color.RED;
				}
			}
		});
		
		color2.addItemListener(new ItemListener(){
			@Override
			public void itemStateChanged(ItemEvent arg0) {
				// TODO Auto-generated method stub
                times2++;
				if(times2%2!=0){
					mycolor=Color.BLUE;
				}
			}
		});
		
		color3.addItemListener(new ItemListener(){
			@Override
			public void itemStateChanged(ItemEvent arg0) {
				// TODO Auto-generated method stub
                times3++;
				if(times3%2!=0){
					mycolor=Color.GREEN;
				}
			}
		});
		
		color4.addItemListener(new ItemListener(){
			@Override
			public void itemStateChanged(ItemEvent arg0) {
				// TODO Auto-generated method stub
                times4++;
				if(times4%2!=0){
					mycolor=Color.YELLOW;
				}
			}
		});
		
		time.addChangeListener(new ChangeListener(){

			@Override
			public void stateChanged(ChangeEvent arg0) {
				// TODO Auto-generated method stub
				t=time.getValue();
				label6.setText(Integer.toString(time.getValue()));
			}
			
		});

	}
    
    
	public void paintComponent(Graphics g){
		g.drawLine(0, 700, 2000, 700);
		g.drawLine(100, 0, 100, 1000);
		g.drawLine(900, 0, 900, 1000);
		g.drawString("the ground", 800, 710);
		
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
      JFrame fram= new JFrame();
      fram.setLayout(new BorderLayout());
      Canvas canvas1=new Canvas();
      
      Canvas canvas3=new Canvas();
      
    
	  
      JLabel label1=new JLabel("angle:");
      JLabel label2=new JLabel("speed:");
      
      JLabel label4=new JLabel("explosion(enter 1-5)");
      JLabel label5=new JLabel("time:");
      JLabel label7=new JLabel("(Notes: Please click one checkbox for color when drawing.)");
     
      
      
      fram.add(canvas1,BorderLayout.PAGE_START);
      fram.add(canvas2, BorderLayout.CENTER);
      fram.add(canvas3, BorderLayout.SOUTH);
     
      
      canvas1.add(label1);
      canvas1.add(angle);
      
      canvas1.add(label2);
      canvas1.add(speed);
     
      canvas1.add(color1);
      canvas1.add(color2);
      canvas1.add(color3);
      canvas1.add(color4);
      
      canvas1.add(label4);
      canvas1.add(explosion);
      canvas1.add(apply);
      
      
      
      canvas3.add(label5);
      canvas3.add(time);
      canvas3.add(label6);
      canvas3.add(label7);
      
      
      fram.setSize(1000, 1000);
      fram.setVisible(true);
      
      fram.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      
	}
    
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==angle){
			m=angle.getText();
			angle.setText(m);
			
		}
		
		if(e.getSource()==speed){
			n=speed.getText();
			speed.setText(n);

		}
	
		Graphics g=getGraphics();
	
		if(e.getSource()==apply){   //for the launch on the left hand side
			
			
			
			anglevalue=Double.valueOf(angle.getText());
			speedvalue=Double.valueOf(speed.getText());
			
			System.out.println(anglevalue);
			System.out.println(speedvalue);
		
		    g.setColor(mycolor);
		
		    x3=1000-(int)(speedvalue*Math.cos(Math.toRadians(anglevalue))*t)-100;
		    y3=-(int)(speedvalue*Math.sin(Math.toRadians(anglevalue))*t-10*t*t/2)+700;
		    
		    x4=(int)(speedvalue*Math.cos(Math.toRadians(anglevalue))*t)+100;
		    y4=-(int)(speedvalue*Math.sin(Math.toRadians(anglevalue))*t-10*t*t/2)+700;
		    
		for(int i=0;i<t;i++){
			
			x1=1000-(int)(speedvalue*Math.cos(Math.toRadians(anglevalue))*i)-100;
			y1=-(int)(speedvalue*Math.sin(Math.toRadians(anglevalue))*i-10*i*i/2)+700;
			x2=1000-(int)(speedvalue*Math.cos(Math.toRadians(anglevalue))*(i+1))-100;
			y2=-(int)(speedvalue*Math.sin(Math.toRadians(anglevalue))*(i+1)-10*(i+1)*(i+1)/2)+700;
			g.drawLine(x1, y1, x2, y2);
			
			
			x5=(int)(speedvalue*Math.cos(Math.toRadians(anglevalue))*i)+100;
			y5=-(int)(speedvalue*Math.sin(Math.toRadians(anglevalue))*i-10*i*i/2)+700;
			x6=(int)(speedvalue*Math.cos(Math.toRadians(anglevalue))*(i+1))+100;
			y6=-(int)(speedvalue*Math.sin(Math.toRadians(anglevalue))*(i+1)-10*(i+1)*(i+1)/2)+700;
			g.drawLine(x5, y5, x6, y6);
			
			
			
			if(x6>getWidth()){
				g.drawString("the explosion is outside the fram...you can widen the fram", 100, 200);
			}
			
			if(y6>700){
				g.drawString("the explosion would be on the ground", 100, 210);
				x3=x2;
				y3=700;
				x4=x6;
				y4=700;
				break;
			}
		}
		
		
		
		if(Integer.valueOf(explosion.getText())==1){
		 
		Random ran=new Random();
		
		
		for(int p=0;p<8;p++){
		   int a=ran.nextInt(60);
		   int b=ran.nextInt(60);
		   int c=ran.nextInt(60);
		   int d=ran.nextInt(60);
		   int f=ran.nextInt(60);
		   int j=ran.nextInt(60);
		   int h=ran.nextInt(60);
		   int l=ran.nextInt(60);
		   g.drawLine(x4,y4,x4+a,y4+b);
		   g.drawOval(x4+a-5, y4+b-5, 10, 10);
		   g.drawLine(x4,y4,x4-c,y4-d);
		   g.drawOval(x4-c-5, y4-d-5, 10, 10);
		   g.drawLine(x4, y4,x4+f, y4-j);
		   g.drawOval(x4+f-5, y4-j-5, 10, 10);
		   g.drawLine(x4, y4, x4-h, y4+l);
		   g.drawOval(x4-h-5, y4+l-5, 10, 10);
		   
		   g.drawLine(x3,y3,x3+a,y3+b);
		   g.drawOval(x3+a-5, y3+b-5, 10, 10);
		   g.drawLine(x3,y3,x3-c,y3-d);
		   g.drawOval(x3-c-5, y3-d-5, 10, 10);
		   g.drawLine(x3, y3,x3+f, y3-j);
		   g.drawOval(x3+f-5, y3-j-5, 10, 10);
		   g.drawLine(x3, y3, x3-h, y3+l);
		   g.drawOval(x3-h-5, y3+l-5, 10, 10);
		}
		}
		
		if(Integer.valueOf(explosion.getText())==2){
			
	      for(int i=1;i<=2;i++){
		    g.drawOval(x4-60*i, y4-20*i, 120*i, 40*i);
		    g.drawOval(x4-20*i, y4-60*i, 40*i, 120*i);
		    
		    g.drawOval(x3-60*i, y3-20*i, 120*i, 40*i);
		    g.drawOval(x3-20*i, y3-60*i, 40*i, 120*i);
		  }
			
		}
		
		if(Integer.valueOf(explosion.getText())==3){
			
			for(int i=1;i<=5;i++){
			g.drawLine(x4-5*i, y4-5*i, x4, y4-15*i);
			g.drawLine(x4+5*i, y4-5*i, x4, y4-15*i);
			g.drawLine(x4+5*i, y4-5*i, x4+15*i, y4);
			g.drawLine(x4+15*i, y4, x4+5*i, y4+5*i);
			g.drawLine(x4+5*i, y4+5*i, x4, y4+15*i);
			g.drawLine(x4, y4+15*i, x4-5*i, y4+5*i);
			g.drawLine(x4-5*i, y4+5*i, x4-15*i, y4);
			g.drawLine(x4-15*i,y4,x4-5*i,y4-5*i);
			
			g.drawLine(x3-5*i, y3-5*i, x3, y3-15*i);
			g.drawLine(x3+5*i, y3-5*i, x3, y3-15*i);
			g.drawLine(x3+5*i, y3-5*i, x3+15*i, y3);
			g.drawLine(x3+15*i, y3, x3+5*i, y3+5*i);
			g.drawLine(x3+5*i, y3+5*i, x3, y3+15*i);
			g.drawLine(x3, y3+15*i, x3-5*i, y3+5*i);
			g.drawLine(x3-5*i, y3+5*i, x3-15*i, y3);
			g.drawLine(x3-15*i,y3,x3-5*i,y3-5*i);
			}
		}
		
		if(Integer.valueOf(explosion.getText())==4){

			Random ran=new Random();
			
			
			for(int p=0;p<3;p++){
			   int a=ran.nextInt(60);
			   int b=ran.nextInt(60);
			   int c=ran.nextInt(60);
			   int d=ran.nextInt(60);
			   int f=ran.nextInt(60);
			   int j=ran.nextInt(60);
			   int h=ran.nextInt(60);
			   int l=ran.nextInt(60);
			   g.drawString("Happy New Year!",x4+a,y4+b);
			  
			   g.drawString("Happy New Year!",x4-c,y4-d);
			  
			   g.drawString("Happy New Year!",x4+f, y4-j);
			   
			   g.drawString("Happy New Year!", x4-h, y4+l);
			   
			   g.drawString("Happy New Year!",x3+a,y3+b);
				  
			   g.drawString("Happy New Year!",x3-c,y3-d);
			  
			   g.drawString("Happy New Year!",x3+f, y3-j);
			   
			   g.drawString("Happy New Year!", x3-h, y3+l);
			  
			}
			
		}
		 
		
		if(Integer.valueOf(explosion.getText())==5){
			g.fillOval(x4-30, (int) (y4-10*Math.sqrt(3)-20), 40, 40);
			g.fillOval(x4-10, (int) (y4-10*Math.sqrt(3)-20), 40, 40);
			g.fillOval(x4, y4-20, 40, 40);
			g.fillOval(x4-10, (int) (y4+10*Math.sqrt(3)-20), 40, 40);
			g.fillOval(x4-30, (int) (y4+10*Math.sqrt(3)-20), 40, 40);
			g.fillOval(x4-40, y4-20, 40, 40);
			
            g.setColor(Color.ORANGE);
			
			g.fillOval(x4-15, y4-15, 30, 30);
			
			g.setColor(mycolor);
			g.fillOval(x3-30, (int) (y3-10*Math.sqrt(3)-20), 40, 40);
			g.fillOval(x3-10, (int) (y3-10*Math.sqrt(3)-20), 40, 40);
			g.fillOval(x3, y3-20, 40, 40);
			g.fillOval(x3-10, (int) (y3+10*Math.sqrt(3)-20), 40, 40);
			g.fillOval(x3-30, (int) (y3+10*Math.sqrt(3)-20), 40, 40);
			g.fillOval(x3-40, y3-20, 40, 40);
			
			g.setColor(Color.ORANGE);
			
			g.fillOval(x3-15, y3-15, 30, 30);
			
		}
		
		if(x3<=x4){         // when the 2 firework hit each other(only works when pressing "apply" first and pressing "apply1" next)
			Random ran=new Random();
			for(int p=0;p<3;p++){
				   int a=ran.nextInt(60);
				   int b=ran.nextInt(60);
				   int c=ran.nextInt(60);
				   int d=ran.nextInt(60);
				   int f=ran.nextInt(60);
				   int j=ran.nextInt(60);
				   int h=ran.nextInt(60);
				   int l=ran.nextInt(60);
				   g.drawString("Hit!!!",500+a,300+b);
				  
				   g.drawString("Hit!!!",500-c,300-d);
				  
				   g.drawString("Hit!!!",500+f, 300-j);
				   
				   g.drawString("Hit!!!", 500-h, 300+l);
				  
				}
			
		}   
		
	 } 
		
		
	 
   
		
	}

	
	
}
