//
//  calculat.c
//  Expr
//
//  Created by Yingtao Liu on 2017/10/9.
//  Copyright © 2017年 Yingtao Liu. All rights reserved.
//

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include "parseTree.h"
#include "calculat.h"
#include "Node.h"



bool isOperand(char c) {
    return (c >= '0' && c <= '9');
}


int value(char c) {
    return (c - '0');
}


double evaluate(char *exp){
    
    if (*exp == '\0') return -1;
    
    double res = value(exp[0]);
    
    for (int i = 1; exp[i]; i += 2){
        
        char opr = exp[i], opd = exp[i+1];
        if (!isOperand(opd)){
            return -1;
        }
        if (opr == '+')	 res += value(opd);
        else if (opr == '-') res -= value(opd);
        else if (opr == '*') res *= value(opd);
        else if (opr == '/') res /= value(opd);
        else return -1;
    }
    return res;
}

void calculator(char string[]){
    printf("%s\n", "connected");
    printf("%s\n", string);
    double result = evaluate(string);
    printf("%f\n", result);
}


