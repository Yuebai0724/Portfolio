//
//  parseTree.c
//  Expr
//
//  Created by Yingtao Liu on 2017/10/9.
//  Copyright © 2017年 Yingtao Liu. All rights reserved.
//

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include "parseTree.h"
#include "Node.h"
#include <math.h>
#define PI 3.14159265
int count=0;

void printSpace(int s){
    if(s!=0){
        printf("%*c", s, ' ');}
}

void print(TREE t, int s){
    printSpace(s);
    printf("%c\n",t->label);
}

void Track(TREE t, int s){
    if(t!=NULL){
        
        print(t,s);
        Track(t->leftmostChild,s+1);
        Track(t->rightSibling,s);
    }
}

void printTree(TREE t){
    int s=0;
    Track(t,s);
    
}

double Et(TREE root){
    
    double e=Tt(root->leftmostChild)+TTt(root->leftmostChild->rightSibling);
    return e;
}
double TTt(TREE root){
    
    if(root->leftmostChild->label=='e'){
        return 0;
    }else{
        TREE n1,n2,n3;
        n1=root->leftmostChild;
        n2=n1->rightSibling;
        n3=n2->rightSibling;
        double result;
        if(n1->label=='+'){
            result= Tt(n2)+TTt(n3);
        }else{
            result= -Tt(n2)-TTt(n3);
        }
        return result;
    }
}
double Tt(TREE root){
    double t= Ft(root->leftmostChild)*FTt(root->leftmostChild->rightSibling);
    return t;
}
double FTt(TREE root){
    if(root->leftmostChild->label=='e'){
        return 1;
    }else{
        TREE n1,n2,n3;
        n1=root->leftmostChild;
        n2=n1->rightSibling;
        n3=n2->rightSibling;
        if(n1->label=='*'){
            double result= Ft(n2)*FTt(n3);
            return result;
        }else{
            double result=1/(Ft(n2)*FTt(n3));
            return result;
        }
    }
}
double Ft(TREE root){
    if(root->leftmostChild->label=='('){
        double result=Et(root->leftmostChild->rightSibling);
        return result;
    }else{
        double result=Ct(root->leftmostChild);
        return result;
    }
}
double Ct(TREE root){
    if(root->leftmostChild->label=='s'){
        double temp=Nt(root->leftmostChild->rightSibling->rightSibling->rightSibling);
        double value = PI / 180.0;
        double count=sin(temp*value);
        return count;
    }else if(root->leftmostChild->label=='c'){
        double temp=Nt(root->leftmostChild->rightSibling->rightSibling->rightSibling);
        double value = PI / 180.0;
       	double count=cos(temp*value);
        return count;
    }else{
        double count=Nt(root->leftmostChild);
        return count;
    }
}
double combine(double a, double b) {
    double times = 1;
    while (times <= b)
        times *= 10;
    return a*times + b;
}
double Nt(TREE root){
    double com=combine(Dt(root->leftmostChild),NTt(root->leftmostChild->rightSibling));
    return com;
}
double NTt(TREE root){
    if(root->leftmostChild->label=='e'){
        return 0;
    }else{
        double n=Nt(root->leftmostChild);
        return n;
    }
}
double Dt(TREE root){
    char c=root->leftmostChild->label;
    if(c=='0'){
        ;
        return 0;
    }else if(c=='1'){
        return 1;
    }else if(c=='2'){
        return 2;
    }else if(c=='3'){
        return 3;
    }else if(c=='4'){
        return 4;
    }else if(c=='5'){
        return 5;
    }else if(c=='6'){
        return 6;
    }else if(c=='7'){
        return 7;
    }else if(c=='8'){
        return 8;
    }else if(c=='9'){
        return 9;
    }
    return 0;
}

