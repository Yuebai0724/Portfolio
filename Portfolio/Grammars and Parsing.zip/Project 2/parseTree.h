//
//  parseTree.h
//  Expr
//
//  Created by Yingtao Liu on 2017/10/9.
//  Copyright © 2017年 Yingtao Liu. All rights reserved.
//

#ifndef parseTree_h
#define parseTree_h

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include "Node.h"

extern char string[100];
extern void printSpace(int s);
extern void print(TREE t, int s);
extern void Track(TREE t, int s);
extern void printTree(TREE t);
extern char ch(TREE t);
extern void Trace(TREE t);
extern double Et(TREE root);
extern double TTt(TREE root);
extern double Tt(TREE root);
extern double FTt(TREE root);
extern double Ft(TREE root);
extern double Ct(TREE root);
extern double combine(double a, double b);
extern double Nt(TREE root);
extern double NTt(TREE root);
extern double Dt(TREE root);

#endif /* parseTree_h */
