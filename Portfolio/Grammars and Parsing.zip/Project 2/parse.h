//
//  parse.h
//  Expr
//
//  Created by Yingtao Liu on 2017/10/9.
//  Copyright © 2017年 Yingtao Liu. All rights reserved.
//

#ifndef parse_h
#define parse_h

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include "Node.h"

#define FAILED NULL
extern void push(TREE k);
extern TREE TOS();
extern void pop() ;
extern bool empty();
extern void display();
extern TREE* stack();
extern TREE parseTree;
extern TREE D();
extern TREE X();
extern TREE N();
extern TREE F();
extern TREE M();
extern TREE T ();
extern TREE K ();
extern TREE E() ;
extern TREE C();
extern TREE D1 (TREE root,char part);
extern TREE C1 (TREE root,char part);
extern TREE X1(TREE root,char part);
extern TREE N1(TREE root,char part) ;
extern TREE F1(TREE root,char part);
extern TREE M1(TREE root,char part);
extern TREE T1 (TREE root,char part);
extern TREE K1 (TREE root,char part) ;
extern TREE E1(TREE root,char part) ;

#endif /* parse_h */
