//
//  Node.h
//  Expr
//
//  Created by Yingtao Liu on 2017/10/9.
//  Copyright © 2017年 Yingtao Liu. All rights reserved.
//

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>



#ifndef Node_h
#define Node_h

typedef struct NODE *TREE;

struct NODE {
    char label;
    TREE leftmostChild;
    TREE rightSibling;
};



extern char *nextTerminal;
extern char *term;
extern TREE makeNode0(char x);
extern TREE makeNode1(char x, TREE t);
extern TREE makeNode2(char x, TREE t1, TREE t2);
extern TREE makeNode3(char x, TREE t1, TREE t2, TREE t3);
extern TREE makeNode4(char x, TREE t1, TREE t2, TREE t3, TREE t4);

#endif /* Node_h */
