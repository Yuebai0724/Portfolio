//
//  main.c
//  Expr
//
//  Created by Yingtao Liu on 2017/10/9.
//  Copyright © 2017年 Yingtao Liu. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "parse.h"
#include "parseTree.h"
#include "calculat.h"
#include "Node.h"

int main() {
    
    term = malloc(sizeof(char)*10);
    term[0]='0';
    term[1]='1';
    term[2]='2';
    term[3]='3';
    term[4]='4';
    term[5]='5';
    term[6]='6';
    term[7]='7';
    term[8]='8';
    term[9]='9';
    
    char pro[9][10]={
        '0','0','0','0','0','0','1','0','1','1',
        'e','e','1','2','e','e','e','e','e','e',
        '0','0','0','0','0','0','1','0','1','1',
        'e','e','e','e','1','2','e','e','e','e',
        '2','0','0','0','0','0','1','0','1','1',
        '0','0','0','0','0','0','1','0','0','0',
        'e','e','e','e','e','e','1','e','0','0',
        '0','0','0','0','0','0','1','0','0','0',
        '0','0','0','0','0','0','3','0','1','2',
    };
    
    
    printf("1 for tree, 2 for table, 3 for calculator\n");
    char a;
    scanf("%c%*c", &a);
    
    if(a == '1'){
        
        printf("Enter an expression to test, or q to quit\n");
        char input[10];
        scanf("%s", input);
        
        while( input[0] != 'q'){
            nextTerminal = input;
            TREE parseTree = E();
            if(parseTree == NULL){
                printf("Invalid input\n");
            }else{
                printTree(parseTree);
            }
            
            printf("Enter an expression to test, or q to quit\n");
            scanf("%s", input);
        }
        
        printf("END\n");
        
        
        return 0;
        
    }else if(a == '2'){
        printf("Enter an expression to test, or q to quit\n");
        char input[10];
        scanf("%s", input);
        
        while( input[0] != 'q' ){
            nextTerminal = input;
            TREE e=makeNode0('E');
            push(e);
            TREE tree=e;
            int boo=1;
            
            while(empty()==false){
                
                TREE root=TOS();
                pop();
                int first;
                int second;
                char label=root->label;
                char sym=*nextTerminal;
                
                if(label==')'){
                    nextTerminal++;
                }else{
                    if(label=='E'){
                        first=0;
                    }else if(label=='K'){
                        first=1;
                    }else if(label=='T'){
                        first=2;
                    }else if(label=='M'){
                        first=3;
                    }else if(label=='F'){
                        first=4;
                    }else if(label=='N'){
                        first=5;
                    }else if(label=='X'){
                        first=6;
                    }else if(label=='C'){
                        first=8;
                    }else{
                        first=7;
                    }
                    if(sym=='('){
                        second=0;
                    }else if(sym==')'){
                        second=1;
                    }else if(sym=='+'){
                        second=2;
                    }else if(sym=='-'){
                        second=3;
                    }else if(sym=='*'){
                        second=4;
                    }else if(sym=='/'){
                        second=5;
                    }else if(sym=='\0'){
                        second=7;
                    }else if(sym=='s'){
                        second=8;
                    }else if(sym=='c'){
                        second=9;
                    }else{
                        second=6;
                    }
                    char part=pro[first][second];
                    TREE treee;
                    if(label=='E'){
                        treee=E1(root,part);
                    }else if(label=='K'){
                        treee=K1(root,part);
                    }else if(label=='T'){
                        treee=T1(root,part);
                    }else if(label=='M'){
                        treee=M1(root,part);
                    }else if(label=='F'){
                        treee=F1(root,part);
                    }else if(label=='N'){
                        treee=N1(root,part);
                    }else if(label=='X'){
                        treee=X1(root,part);
                    }else if(label=='C'){
                        treee=C1(root,part);
                    }else{
                        treee=D1(root,part);
                    }
                    if(treee==NULL){
                        printf("Invalid Input\n");
                        boo=0;
                        break;
                    }
                }
            }
            if(boo==1){
                printTree(tree);
            }
            
            printf("Enter an expression to test, or q to quit\n");
            scanf("%s", input);
        }
        
        printf("END\n");
        return 0;
        
    }else if(a == '3'){
        printf("Enter an expression to test, or q to quit\n");
        char input[10];
        scanf("%s", input);
        
        while( input[0] != 'q'){
            nextTerminal = input;
            TREE parseTree = E();
            
            if(parseTree == NULL){
                printf("%s\n", "Invalid input");
            }else{
                printf("Result ");
                printf("%f\n",Et(parseTree));
            }
            printf("Enter an expression to test, or q to quit\n");
            
            scanf("%s", input);
        }
        
        printf("END\n");
        return 0;
    }
    
}
