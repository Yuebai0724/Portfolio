Collaborator: Yingtao Liu, Zixuan Wang, Yuebai Gao
NetID: yliu157, zwang92, ygao41


How to run the code:
We have done all parts in this program and the extra credit
there is a "exe" file in this zip file 
which can be used directly to generate some results.


How to demonstrate:
Follow the prompt. 1 for tree, 2 for table, 3 for calculator.


The grammar used in this project is shown below:
<F> -> (<E>) | <N>
<M> -> *<F><M> | /<F><M> | e
<T> -> <F><M>
<K> -> +<T><K> | -<T><K> | e
<N> -> <D><X>
<X> -> <N> | e
<X> -> <C> | e
<C> ->sincos<N>|<N>
