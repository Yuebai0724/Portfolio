//
//  calculat.h
//  Expr
//
//  Created by Yingtao Liu on 2017/10/9.
//  Copyright © 2017年 Yingtao Liu. All rights reserved.
//

#ifndef calculat_h
#define calculat_h


#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include "parseTree.h"
#include "calculat.h"
#include "Node.h"

extern bool isOperand(char c);
extern int value(char c);
extern double evaluate(char *exp);
extern void calculator(char string[]);
#endif /* calculat_h */
