* Creator: Yuebai Gao
* Course: CSC 173
* Project 3


For this project, I wrote functions for all 3 parts.

For part 1, I wrote “myappend”(1), “myreverse”(2), “mymap”(3), “nub”(4).

For part 2, I wrote “mymember”(1), “myinsert”(2), “myintersection”(3), “myunion”(4),
“mydiffer”(5), “symdiffer”(6)

For part 3, I wrote “myabs”(1), “factorial”(2), “mygcd”(4), “mylcm”(5)

Also, I wrote the 3 required functions: “perfect?”, “abundant”, “deficient”.