import java.util.*;


public class course {
	
	public course(){
		
	}
	
	Hole[] hole=new Hole[18];
	
	String [] Gname={"one","two","three","four","five","six","seven","eight","nine","ten","eleven","twelve","thirteen","fourteen","fifteen","sixteen","seventeen","eighteen"};
	int [] Gyard={530,305,331,201,500,226,409,410,229,433,363,174,545,419,512,410,320,170};
	int [] Gpar={5,4,4,3,5,3,4,4,3,4,4,3,5,4,5,4,4,3};
	int [] Syard={376,453,397,480,568,412,371,175,352,386,174,348,465,618,455,423,495,357};
	int [] Spar={4,4,4,4,5,4,4,3,4,4,3,4,4,5,4,4,4,4};
	String [] Sname={"Burn","Dyke","Cartgate(Out)","Ginger Beer","Hole O' Cross(Out)","Heathery(Out)","High(Out)","Short","End","Bobby Jones","High(In)","Heathery(In)","Hole O' Cross(In)","Long","Cartgate(In)","Corner of the Dyke","Road","Tom Morris"};
	
	int [] clubmean={230,215,180,170,155,145,135,125,110,50};
	int [] clubstd={30,20,20,17,15,15,15,15,10,10};

	
	
	
	
	
	
	public int getGyard(int n){
		return Gyard[n];
	}
	public int getGpar(int n){
		return Gpar[n];
	}
	public String getGname(int n){
		return Gname[n];
	}
	public String getSname(int n){
		return Sname[n];
	}
	public int getSyard(int n){
		return Syard[n];
	}
	public int getSpar(int n){
		return Spar[n];
	}
	
	public void Select(int n){
		if(n==1){
			for(int i=0;i<18;i++){
				hole[i]=new Hole(Gname[i],Gyard[i],Gpar[i]);
			}
			
		}
		else if(n==2){
			for(int i=0;i<18;i++){
				hole[i]=new Hole(Sname[i],Syard[i],Spar[i]);
			}
		}
		
		
		
	}
	
	
	
	
	
	
	
	

}
