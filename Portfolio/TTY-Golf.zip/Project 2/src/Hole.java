
public class Hole {
	protected String name;
	protected int yards;
	protected int par;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getYards() {
		return yards;
	}
	public void setYards(int yards) {
		this.yards = yards;
	}
	public int getPar() {
		return par;
	}
	public void setPar(int par) {
		this.par = par;
	}
	
	public Hole(String name, int yards, int par){
		this.name=name;
		this.yards=yards;
		this.par=par;
	}
	
	
	
	
	
	
	

}
