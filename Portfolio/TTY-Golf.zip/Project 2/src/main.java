import java.util.*;
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scan=new Scanner(System.in);
		Random random=new Random();
		int score = 0;
    System.out.println("Welcome to TTY Golf!");
    int quit; //create a variable so that player can quit
	
    
	do{
	   System.out.println("Would you like to play the game?(Enter 1 to play; 0 to quit)");
	   quit=scan.nextInt(); //player can quit the game after a round if he enter 0
	   if(quit==0){
		   break;
	   }
       System.out.println("Please select a course: 1. Genesee Valley Park North Course 2. The Old Course at St. Andrews ");
       System.out.println("Your choice [1-2]: ");	
	
	   int choice =scan.nextInt();
	   
	   int hit1=0;// set the number for hits of one around
	  
	      if(choice==1){
		    System.out.println("You are playing the Genesee Valley Park North Course.");
		
		     
		        course a =new course();
		        Club b=new Club();
	            b.club();
	            a.Select(1); //select the course 1 which is Genesee
	            
	            for(int i=0;i<18;i++){ //the loop would keep going for 18 holes
	                int hit2=0;//set the number for hits of every single hole
	                System.out.println("You are at the "+a.getGname(i)+" tee.");
		            System.out.println(a.getGyard(i)+" yards, par "+a.getGpar(i));
		            double awayyards=a.getGyard(i);
		            //before the player starts first hit, the distance between he and the hole is set in the array in class Club
		            score=score-a.hole[i].par;
		            //the score before the first hit is negative
		            
		            
		            System.out.println("Your score starts at "+score+";your score would +1 every time you have a hit(the goal is to get as lower score as you can)");
		         //before the player starts first hit, his score is -par; as he starts hitting, score would plus 1 every time he has a hit
		         //every time when the player starts a new hole, the score would minus the par for that hole
		            //the goal is to get as lower score as you can   
		            do{
		        
		               
		               
		              
		               System.out.println("Choose your club[1-10]:");
		               System.out.println("Press 0 to quit the game.");
		               int club1=scan.nextInt(); //choose your club
		               if(club1==0){ //if you enter 0 here, you will break the loop, which means the game will end
		            	   break;
		               }
		               
		               
		               System.out.println("You choose "+b.clubname(club1-1)+" club.");
		               //inform the player which club he chose
		               System.out.println("Your power[1-10]:");
		               System.out.println("Press 0 to quit the game.");
		               int power1=scan.nextInt(); //choose your power
		               if(power1==0){
		            	   break;
		               }
		               
		               
		               System.out.println("You choose power "+power1);
		               //inform the player which power he chose
		        
		               double hityards=b.computeDistance(club1-1, power1-1);
		        //compute the yards using the method 'computeDistance' (since the index number is 1 less than the club number and power number player chose, so we use club-1 and power-1 when computing)
		               
		               hit1++;
		               hit2++;
		               score++; //the score +1 every time player make a hit
		        
		               System.out.println("You hit the ball "+hityards+" yards."); 
		               System.out.println("Hit for this hole: "+hit2);
		               System.out.println("Total hits for this round: "+hit1);
		
		               awayyards = Math.abs(awayyards-hityards); //compute how many yards is the ball away from the hole at this point
		
		               if (awayyards>20){
			               System.out.println("You are "+awayyards+" yards from the hole");
			               
			               
			               int sand=random.nextInt(a.getGyard(i));
			               int water=random.nextInt(a.getGyard(i));
			               
			               if(awayyards>water&&awayyards<water+3){ //suppose the water hazard is 3 yards long
			            	   System.out.println("You hit your ball in the water hazard. You will go back to your last position.)");
			            	   awayyards=awayyards+hityards;
			               }
			               
			               if(awayyards>sand&&awayyards<sand+3){ //suppose the sand trap is 3 yards long
			            	   System.out.println("You hit your ball in the sand trap. You have to use the number 10 club--Wedge.");
			            	   System.out.println("Choose your power[1-10]:");
			            	   System.out.println("Enter 0 to quit");
			            	   int power=scan.nextInt();
			            	   
			            	   if(power==0){ //player can quit the game here
			            		   break;
			            	   }
			            	   
			            	   hityards=b.sandDistance(power);
			            	   
			            	   hit1++;
				               hit2++;
				               score++; //the score +1 every time player make a hit
				        
				               System.out.println("You hit the ball "+hityards+" yards."); 
				               System.out.println("Hit for this hole: "+hit2);
				               System.out.println("Total hits for this round: "+hit1);
				
				               awayyards = Math.abs(awayyards-hityards);
				               
				               System.out.println("You are "+awayyards+" yards away from the hole.");
			            	   
			               }
			               
			               
			               
		               }
		               else if(awayyards==0){
			               System.out.println("You hit the hole directly!!");
		               }
		               else if(awayyards<=20){
			               System.out.println("You are in the green.");
		               }
		                   System.out.println("Your current score is "+score);
		
		           }while(awayyards>20);
		            
		            
		            double awayfeet=3*awayyards;
		            
		            while(awayyards<=20&&awayyards!=0){ //when the ball is less or equal to 20 yards away from the hole, it's inside the green
		            	
		            	
		            	System.out.println("Power[1-10]: ");
		            	System.out.println("Enter 0 to quit");
		            	int power=scan.nextInt();
		            	if(power==0){ //if you enter 0 here, you will break the loop, which means the game will end
			            	   break;
			               }
		            	
		            	double hitfeet=b.computePutt(power-1);
		            	System.out.println("You put "+ hitfeet+" feet.");
		            	hit1++;
		            	hit2++;
		            	score++;
		            	System.out.println("Hit for this hole: "+hit2);
		            	System.out.println("Total hits for this round: "+hit1);
		            	
		            	awayfeet=Math.abs(awayfeet-hitfeet);
		            	
		            	if(awayfeet>1){
		            		System.out.println("You are "+awayfeet+" feet to the hole!");
		            		System.out.println("Your current score is "+score);
		            	}
		            	else{
		            		System.out.println("You hit the ball into the hole!!");
		            		System.out.println("Your final score is "+score);
		            		System.out.println("");
		            		break;
		            	}
		            
		            }
		           System.out.println("Do you want to continue playing?(Enter 1 to continue;0 to quit)"); 
		           quit=scan.nextInt();
		           if(quit==0){
		        	   break;
		           }
		            
		       }
	      } //the semicolon for if statement to decide which course to play
	      
	      
	      
	      
	      
	      
	      
	  else if(choice==2){
		 System.out.println("You are playing the old course at St. Andrew.");
		 course a =new course();
	     Club b=new Club();
         b.club();
         a.Select(2);
         
         for(int i=0;i<18;i++){
                int hit2=0;
                System.out.println("You are at the "+a.getSname(i)+" tee.");
	            System.out.println(a.getSyard(i)+" yards, par "+a.getSpar(i));
	            double awayyards=a.getSyard(i);
	            score=score-a.hole[i].par;
	        
	            do{
	        
	               System.out.println("Choose your club[1-10]:");
	               System.out.println("Press 0 to quit the game.");
	               int club1=scan.nextInt();
	               
	               if(club1==0){  //the player can quit the game here
	            	   break;
	               }
	               
	               System.out.println("You choose "+b.club[i].clubname(i)+" club.");
	               System.out.println("Your power[1-10]:");
	               System.out.println("Press 0 to quit the game.");
	               int power1=scan.nextInt();
	               
	               if(power1==0){  //the player can quit the game here
	            	   break;
	               }
	               System.out.println("You choose power "+power1);
	        
	               double hityards=b.computeDistance(club1-1, power1-1);
	        
	               hit1++;
	               hit2++;
	               score++;
	        
	               System.out.println("You hit the ball "+hityards+" yards.");
	               System.out.println("Hit for this hole: "+hit2);
	               System.out.println("Total hits for this round: "+hit1);
	
	               awayyards = Math.abs(awayyards-hityards);
	
	               if (awayyards>20){
		               System.out.println("You are "+awayyards+" yards from the hole");
		               
		               int sand=random.nextInt(a.getGyard(i));
		               int water=random.nextInt(a.getGyard(i));
		               
		               if(awayyards>water&&awayyards<water+3){ //suppose the water hazard is 3 yards long
		            	   System.out.println("You hit your ball in the water hazard. You will go back to your last position.)");
		            	   awayyards=awayyards+hityards;
		               }
		               
		               if(awayyards>sand&&awayyards<sand+3){ //suppose the sand trap is 3 yards long
		            	   System.out.println("You hit your ball in the sand trap. You have to use the number 10 club--Wedge.");
		            	   System.out.println("Choose your power[1-10]:");
		            	   System.out.println("Enter 0 to quit");
		            	   int power=scan.nextInt();
		            	   
		            	   if(power==0){  //you can quit the game here
		            		   break;
		            	   }
		            	   
		            	   hityards=b.sandDistance(power);
		            	   
		            	   hit1++;
			               hit2++;
			               score++; //the score +1 every time player make a hit
			        
			               System.out.println("You hit the ball "+hityards+" yards."); 
			               System.out.println("Hit for this hole: "+hit2);
			               System.out.println("Total hits for this round: "+hit1);
			
			               awayyards = Math.abs(awayyards-hityards);
			               System.out.println("You are "+awayyards+" yards from the hole. ");
		            	   
		               }
	               }
	               else if(awayyards==0){
		               System.out.println("You hit the hole directly!!");
	               }
	               else if(awayyards<=20){
		               System.out.println("You are in the green.");
	               }
	                   System.out.println("Your current score is "+score);
	
	           }while(awayyards>20);
	            
	            
	            double awayfeet=3*awayyards; //transform from yards to feet
	            
	            while(awayyards<20&&awayyards!=0){
	            	
	            	System.out.println("Power[1-10]: ");
	            	System.out.println("Enter 0 to quit");
	            	int power=scan.nextInt();
	   
	            	if(power==0){ //if you enter 0 here, you will break the loop, which means the game will end
		            	   break;
		               }
	            	
	            	double hitfeet=b.computePutt(power-1);
	            	System.out.println("You put "+ hitfeet+" feet.");
	            	hit1++;
	            	hit2++;
	            	score++;
	            	System.out.println("Hit for this hole: "+hit2);
	            	System.out.println("Total hits for this round: "+hit1);
	            	
	            	awayfeet=Math.abs(awayfeet-hitfeet);
	            	
	            	if(awayfeet>1){
	            		System.out.println("You are "+awayfeet+" feet to the hole!");
	            		System.out.println("Your current score is "+score);
	            	}
	            	else{
	            		System.out.println("You hit the ball into the hole!!");
	            		System.out.println("Your final score is "+score);
	            		System.out.println("");
	            		
	            		break;
	            	}
	            	
	            	
	            	
	            	
	            	
	            }
	             System.out.println("Do you want to continue playing?(Enter 1 to continue;0 to quit)"); 
		           quit=scan.nextInt();
		           if(quit==0){
		        	   break;
		           }
	            
	            
	       }
		
	  }
		
	}while(quit!=0);
	
	
	System.out.println("Your final score is "+score);
	System.out.println("Thank you for playing!");
	


	
}}
