import java.util.*;
public class Club {
    private String name;
    private int mean;
    private int std;
	
    public Club(String name, int mean, int std){
		this.name=name;
		this.mean=mean;
		this.std=std;
	}
    
    public Club(){
    	
    }
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMean() {
		return mean;
	}
	public void setMean(int mean) {
		this.mean = mean;
	}
	public int getStd() {
		return std;
	}
	public void setStd(int std) {
		this.std = std;
	}

    Club [] club = new Club[10];
	
	String [] clubname={"Driver","3-wood","3-iron","4-iron","5-iron","6-iron","7-iron","8-iron","9-iron","Wedge"};
	int [] clubmean={230,215,180,170,155,145,135,125,110,50};
	int [] clubstd={30,20,20,17,15,15,15,15,10,10};
	
	Club []putt=new Club[10];

	int[] puttmean={1,2,4,8,12,16,20,25,30,40};
	int[] puttstd={1,1,2,2,3,3,4,4,5,5};
	
	public String clubname(int i){
		return clubname[i];
	}
	
	
	
	
	public void club(){
		for(int i=0;i<10;i++){
			club[i]=new Club(clubname[i],clubmean[i],clubstd[i]);
		}
	}
	
	public void putt(){
		for(int i=0;i<10;i++){
			putt[i]=new Club("",puttmean[i],puttstd[i]);
		}
	}
	
	
	public double computeDistance(int clubnum,int power){
		Random random = new Random();
		double mean_adj=clubmean[clubnum]*power/10.0;
		double stddev_adj=clubstd[clubnum]*power/10.0;
		double val=Math.abs(random.nextGaussian()*stddev_adj+mean_adj);
		return val;
	}
	
	public double sandDistance(int power){ //create a special method to compute the yards hit by player when the ball is in the sand trap
		Random random = new Random();
		double mean_adj=clubmean[9]*power/10.0; //the player can only use number 10 club--Wedge
		double stddev_adj=clubstd[9]*power/10.0;
		double val=Math.abs(random.nextGaussian()*stddev_adj+mean_adj);
		return val;
	}
	
	public double computePutt(int power){
		Random random=new Random();
		double mean_adj=puttmean[power];
		double stddev_adj=puttstd[power];
		double val=Math.abs(random.nextGaussian()*stddev_adj+mean_adj);
		return val;
	}
	
	
}
