NAME: Yuebai Gao
net ID: ygao41
UR email: ygao41@u.rochester.edu
I did not collaborate with anyone on this assignment.

In this project, I try to get extra credits by 
1. using the old terminology
2. letting the player to quit every time when he enters club number, power and when 
he finishes hitting one hole.
3. I also set water hazard and sand trap for every hole. I use random number to decide where to start
the hazard and trap. And I set both the hazard and trap 3 yards long. If the player hit the ball 
inside the water hazard, he has to restart this hit; if the player hit the ball inside the sand 
trap, he can only use number 10 club--Wedge for the next hit. 

I use seperate classes: course, Club, Hole and main in this project.