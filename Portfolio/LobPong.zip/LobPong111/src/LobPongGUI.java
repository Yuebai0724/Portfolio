
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

// this class sets up the info bar on top of the game panel. It is menu.

public class LobPongGUI extends JPanel implements ActionListener{
	protected JLabel label1, label2, label3, label4;//use to write the score,live,time and level
	protected static JLabel remainingLives;
	protected static JLabel scoreBoard;
	protected JLabel remainingTime;
	protected JLabel lvl;
	protected static Timer t;
	protected static int time = 60;		// time duration
	protected static int score = 0;
	protected static int lives = 5;
	protected static int level = 1;
	
	//set up the GUI on the top. The width,height and layout.Add info into menu
	public LobPongGUI(){
		setSize(LobPong.width,LobPong.height/12);
		setLayout(new FlowLayout());
		label1 = new JLabel("Lives: ");
		add(label1);
		remainingLives = new JLabel();
		add(remainingLives);
		remainingLives.setText(Integer.toString(lives));
		
		label2 = new JLabel("     Score: ");
		add(label2);
		scoreBoard = new JLabel();
		add(scoreBoard);
		scoreBoard.setText(Integer.toString(score));
		
		t = new Timer(1000,this);
		label3 = new JLabel("     Time: ");
		add(label3);
		remainingTime = new JLabel();
		add(remainingTime);
		remainingTime.setText(Integer.toString(time));
		
		label4 = new JLabel("     Level: ");
		add(label4);
		lvl = new JLabel();
		add(lvl);
		lvl.setText(Integer.toString(level));
		
	}

	public static void timerStart(){
		t.start();
	}
	
	@Override
	//the method that level up that time go to 60s again. And score, lives method
	public void actionPerformed(ActionEvent e) {
		if(time>0){
			time--;
			remainingTime.setText(Integer.toString(time));
		}
		if(time==0){
			t.stop();
			level++;
			lvl.setText(Integer.toString(level));
		}
	}

	public static void ballScores(){
		score++;
		scoreBoard.setText(Integer.toString(score));
	}
	
	public static void loseLife(){
		lives--;
		remainingLives.setText(Integer.toString(LobPong.lives));
		
	}
}

