
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

public class LobPong extends JPanel implements KeyListener, ActionListener{

	protected int upY, leftX, size;  	// ball position (leftX and upY represents the upper left corner when drawing the ball
	protected int paddleLeftX, paddleUpperY;		// paddle position
	protected int paddleSpeed = 80;			// how fast the paddle moves
	protected int paddleWidth = 150;				
	protected static int lives;						// lives that the player has
	protected static int score;						// player's score
	protected int speed, angle;						// ball's initial speed and angle
	protected double speedX, speedY;				// split ball's velocity into vertical(Y) and horizontal(X)
	protected int keyCode;							// may not need at the end
	protected static Timer timer;					
	protected static int level = 1;
	protected static int width = 1200; 
	protected static int height = 800;
	protected static JPanel GUIpanel;
	protected Random rand = new Random();
	
	
	public LobPong(){
		this.addKeyListener(this);
		this.setFocusable(true);
		setSize(width,height*11/12);
		paddleLeftX = getWidth()/2-paddleWidth/2;
		paddleUpperY = getHeight()-40;
		size = 20;
		leftX = getWidth()/2-size/2;		// the left X of ball is middle of the paddle - half ball size
		upY = getHeight() - 40 - size;
		lives = 5;							// every time player gets five lives
		score = 0;
		timer = new Timer(10,this);
		speed = 100 + rand.nextInt(50);
		angle = 60 + rand.nextInt(60);
		speedX = speed*Math.cos(Math.toRadians(angle));
		speedY = speed*Math.sin(Math.toRadians(angle));
	}
	
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		g.setColor(Color.BLUE);
		g.fillRect(0, 0, getWidth(), getHeight());
		// draws paddle
		g.setColor(Color.ORANGE);
		g.fillRect(paddleLeftX, paddleUpperY, paddleWidth, 40); 	// width of the paddle is getWidth()/8
		
		// draws ball
		g.setColor(Color.WHITE);
		g.fillOval(leftX, upY, size, size);
		
		// draws obstacles
		g.setColor(Color.YELLOW);
		g.fillRect(getWidth()*3/4, getHeight()/2, getWidth()/4, 15);
		g.fillRect(getWidth()*5/6, getHeight()/4, getWidth()/6, 15);
		g.setColor(Color.CYAN);
		g.fillRect(0, getHeight()/5, getWidth()/6, 15);
		g.fillRect(0, getHeight()*2/5, getWidth()/4, 15);
		g.setColor(Color.PINK);
		g.fillRect(getWidth()/3, getHeight()/3, getWidth()/15, getWidth()/15);
		g.fillRect(getWidth()/2, getHeight()/5, getWidth()/15, getWidth()/15);
		g.fillRect(getWidth()*2/3, getHeight()/3, getWidth()/15, getWidth()/15);
		
		//if lives equal 0,the game is over
		if(lives==0){
			g.setColor(Color.WHITE);
			g.setFont(new Font(Font.DIALOG, Font.BOLD, 36));
			g.drawString("GAME OVER", getWidth()*7/16, getHeight()/6);
		}
		
		//if time equal 0 and lives bigger than 0, you can play next level. Next level the speed is faster and game is difficult.
		if(LobPongGUI.time == 0 && lives > 0){
			g.setColor(Color.WHITE);
			g.setFont(new Font(Font.DIALOG, Font.BOLD, 36));
			g.drawString("Good Job! Next Level! (Press 'N' to Continue)", getWidth()/5, getHeight()/6);
			
		}
	}
	
	public void timerStart(){
		timer.start();
	}
	
	@Override
	public void keyPressed(KeyEvent e) {
		Graphics g = getGraphics();
		keyCode = e.getKeyCode();
		
		// use left and right arrow keys to move paddle
		if(keyCode == KeyEvent.VK_LEFT && paddleLeftX >= 0){
			paddleLeftX -= paddleSpeed;
			g.fillRect(paddleLeftX, paddleUpperY, paddleWidth, 40);
			repaint();
		}
		
		if(keyCode == KeyEvent.VK_RIGHT && paddleLeftX + paddleWidth <= width){
			paddleLeftX += paddleSpeed;
			g.fillRect(paddleLeftX, paddleUpperY, paddleWidth, 40);
			repaint();
		}
		
		// space bar starts and continues the game
		if(keyCode == KeyEvent.VK_SPACE && lives > 0){
			timerStart();
			LobPongGUI.timerStart();
		}
		
		
		// for next level
		if(keyCode == KeyEvent.VK_N ){
			LobPongGUI.time=60;
			speed = 150 + rand.nextInt(50);
			angle = 60 + rand.nextInt(60);
			speedX = speed*Math.cos(Math.toRadians(angle));
			speedY = speed*Math.sin(Math.toRadians(angle));
			timerStart();
			LobPongGUI.t.start();
		}
	}

	public void keyReleased(KeyEvent e) {
		
	}

	public void keyTyped(KeyEvent e) {
		
	}

	
	public void actionPerformed(ActionEvent e) {
		double t = 0.1;
		leftX += (int)(speedX*t);
		speedY -= 9.8*t;
		upY -= (int)(speedY*t + 0.5*9.8*Math.pow(0.1, 2.0));
		Graphics g = getGraphics();
		repaint();
		
		if(LobPongGUI.time==0 && lives>0){
			timer.stop();
		}
		
		// ball bounces back when hitting left and right sides
		if(leftX + size > getWidth() || leftX<0){
			speedX = -1.0*speedX;
		} 
		
		// ball bounces back when hitting the upper border
		if(upY<0){
			speedY = -1.0*speedY;
		}
		
		// ball hits bottom and loses life
		// Every time the ball hits the bottom, the animation stops and the lives decreases by 1. 
		// Simply press the space bar, the ball will launch with a new random speed and angle, and the game starts again
		if(upY + size > getHeight()){
			speedY = -1.0*speedY;
			timer.stop();
			lives--;
			LobPongGUI.t.stop();
			LobPongGUI.loseLife();
			System.out.println("Lives: "+lives);
			
			speed = 120 + rand.nextInt(50);
			angle = 60 + rand.nextInt(60);
			speedX = speed*Math.cos(Math.toRadians(angle));
			speedY = speed*Math.sin(Math.toRadians(angle));
			
			// if the balls hits the bottom and lives is 0, the game is over
			if(lives==0){
				g.setColor(Color.WHITE);
				g.setFont(new Font(Font.DIALOG, Font.BOLD, 36));
				g.drawString("GAME OVER", getWidth()/2, getHeight()/6);
			}
		}
		
		// bounce off paddle
		if(leftX+size > paddleLeftX && leftX < paddleLeftX+paddleWidth && 
				upY+size>paddleUpperY && upY+size<paddleUpperY+20){
			speedY = -1.0*speedY;	
			LobPongGUI.ballScores();
			score++;
			System.out.println(score);
		}
		
		// obstacles: bars on the right
		if((leftX+size > getWidth()*3/4 && upY+size>getHeight()/2 && upY+size<getHeight()/2+15)||
				(leftX+size > getWidth()*3/4 && upY>getHeight()/2 && upY<getHeight()/2+15)) {
			speedY = -1.0*speedY;
		}
		if(leftX+size>getWidth()*3/4 && leftX+size < getWidth()*3/4 + size
				&& upY+size>getHeight()/2 && upY+size<getHeight()/2+15){
			speedX = -1.0*speedX;
		}
		
		if((leftX+size > getWidth()*5/6 && upY+size>getHeight()/4 && upY+size<getHeight()/4+15)||
				(leftX+size > getWidth()*5/6 && upY>getHeight()/4 && upY<getHeight()/4+15)) {
			speedY = -1.0*speedY;
		}
		if(leftX+size>getWidth()*5/6 && leftX+size < getWidth()*5/6 + size
				&& upY+size>getHeight()/4 && upY+size<getHeight()/4+15){
			speedX = -1.0*speedX;
		}
		
		//obstacles: bars on the left
		if((leftX < getWidth()/6 && upY+size>getHeight()/5 && upY+size<getHeight()/5+15)||
				(leftX < getWidth()/6 && upY>getHeight()/5 && upY<getHeight()/5+15)) {
			speedY = -1.0*speedY;
		}
		if(leftX<getWidth()/6 && leftX > getWidth()/6 - size
				&& upY+size>getHeight()/5 && upY+size<getHeight()/5+15){ 
			speedX = -1.0*speedX;
		}
		
		if((leftX < getWidth()/4 && upY+size>getHeight()*2/5 && upY+size<getHeight()*2/5+15)||
				(leftX < getWidth()/4 && upY>getHeight()*2/5 && upY<getHeight()*2/5+15)) {
			speedY = -1.0*speedY;
		}
		if(leftX<getWidth()/4 && leftX > getWidth()/4 - 5		//change size to 5
				&& upY+size>getHeight()*2/5 && upY+size<getHeight()*2/5+5){ // change 15 to 5
			speedX = -1.0*speedX;
		}
		
		// obstacles: the left square
		if((leftX+size > getWidth()/3 && leftX < getWidth()/3+getWidth()/15 && 
				upY+size>getHeight()/3 && upY+size<getHeight()/3+size)   ||
				(leftX+size > getWidth()/3 && leftX < getWidth()/3+getWidth()/15 && 
						upY<getHeight()/3+getWidth()/15 && upY>getHeight()/3+getWidth()/15-size)) {
			speedY = -1.0*speedY;
		}
		if((upY+size>getHeight()/3 && upY < getHeight()/3+getWidth()/15 &&
				leftX+size>getWidth()/3 && leftX+size<getWidth()/3+5)  ||	// changes size to 5
				(upY+size>getHeight()/3 && upY < getHeight()/3+getWidth()/15 &&
					leftX<getWidth()/3+getWidth()/15 && leftX>getWidth()/3+getWidth()/15-5) // changes size to 5
				){
			speedX = -1.0*speedX;
		}
		
		// obstacles: the middle square
		if((leftX+size > getWidth()/2 && leftX < getWidth()/2+getWidth()/15 && 
				upY+size>getHeight()/5 && upY+size<getHeight()/5+size)   ||
				(leftX+size > getWidth()/2 && leftX < getWidth()/2+getWidth()/15 && 
						upY<getHeight()/5+getWidth()/15 && upY>getHeight()/5+getWidth()/15-size)) {
			speedY = -1.0*speedY;
		}
		if((upY+size>getHeight()/5 && upY < getHeight()/5+getWidth()/15 &&
				leftX+size>getWidth()/2 && leftX+size<getWidth()/2+5)  ||	// changes size to 5
				(upY+size>getHeight()/5 && upY < getHeight()/5+getWidth()/15 &&
					leftX<getWidth()/2+getWidth()/15 && leftX>getWidth()/2+getWidth()/15-6)	// changes size to 5
				){
			speedX = -1.0*speedX;
		}
		
		// obstacles: the right square
		if((leftX+size > getWidth()*2/3 && leftX < getWidth()*2/3+getWidth()/15 && 
				upY+size>getHeight()/3 && upY+size<getHeight()/3+size)   ||
				(leftX+size > getWidth()*2/3 && leftX < getWidth()*2/3+getWidth()/15 && 
						upY<getHeight()/3+getWidth()/15 && upY>getHeight()/3+getWidth()/15-size)) {
			speedY = -1.0*speedY;
		}
		if((upY+size>getHeight()/3 && upY < getHeight()/3+getWidth()/15 &&
				leftX+size>getWidth()*2/3 && leftX+size<getWidth()*2/3+5)  ||		// changes size to 5
				(upY+size>getHeight()/3 && upY < getHeight()/3+getWidth()/15 &&
					leftX<getWidth()*2/3+getWidth()/15 && leftX>getWidth()*2/3+getWidth()/15-5)	// change size to 5
				){
			speedX = -1.0*speedX;
		}
		
	}
	
	public static void main(String[] args) {
		JFrame frame = new JFrame();
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(width, height);
		frame.setLayout(new BorderLayout());
		LobPong game = new LobPong();
		GUIpanel = new LobPongGUI();
		frame.add("North",GUIpanel);
		frame.add("Center", game);
		game.requestFocusInWindow();
	}

}

