NAME: Yuebai Gao
net ID: ygao41
UR email: ygao41@u.rochester.edu
I did not collaborate with anyone on this assignment.