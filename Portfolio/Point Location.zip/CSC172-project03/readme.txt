NAME: Yuebai Gao
E-MAIL: ygao41@u.rochester.edu
LAB SESSION: MW 1525-1640
Course: CSC 172
DATE: 3/31/2017

BREID DESCRIPTION OF THE PROJECT
In this project, I rebuild the binary tree structure to fulfill the requirements of inserting
lines. I also add the "Locate" method and "FindLine" method in the MyTreeNode to
locate the points(whether they are in the same space or not) and to find lines between
the 2 points. After inserting all the lines in the tree, I print out the tree in order.

Some methods in the PointLocation class are useless since they are just written in case
I need them, e.g. the "numberOfSpace" method.

Also, I did the extra credit of using graphics but I haven't finished it...
You can give me points if you like.

The implementation provided further
All the methods are tested.