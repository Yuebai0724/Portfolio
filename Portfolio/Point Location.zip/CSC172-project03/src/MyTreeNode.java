public class MyTreeNode<T extends Comparable<T>> { 
	public Line line; 
	public MyTreeNode<T> leftChild;
    public MyTreeNode<T> rightChild; 
    public MyTreeNode<T> parent;
    
        
    public MyTreeNode(){
    	line=null;
    	leftChild=null;
    	rightChild=null;
    	parent=null;
    }
    
   
    public static int ccw(Point p0, Line l) {  
		int COUNTERCLOCKWISE=1;
		int CLOCKWISE=-1;
		int COLINEAR=0;
		double lx1=l.p1.x;
		double lx2=l.p2.x;
		double ly1=l.p1.y;
		double ly2=l.p2.y;
		double dx1 = lx2-lx1;    
		double dy1 = ly2 - ly1;    
		double dx2 = p0.x -lx1;    
		double dy2 = p0.y - ly1;    
		if (dx1*dy2 > dy1*dx2) return COUNTERCLOCKWISE;    
		else if (dx1*dy2 < dy1*dx2) return CLOCKWISE;    
		else if ((dx1*dx2 < 0) || (dy1*dy2 < 0)) return CLOCKWISE;    
		else if ((dx1*dx1+dy1*dy1) < (dx2*dx2+dy2*dy2)) return COUNTERCLOCKWISE;    
		else return COLINEAR; 
		
}
    
public static int LineDirection(Line l1, Line l2){
	if(ccw(l2.p1,l1)!=ccw(l2.p2,l1)){
		if(ccw(l2.p1,l1)==0){
			return ccw(l2.p2,l1);
		}else if(ccw(l2.p2,l1)==0){
			return ccw(l2.p1,l1);
		}else{
			return 0;
		}
	}else{
		return ccw(l2.p1,l1);
	}
}
    
public double a(Point p1, Point p2){
	 return (p2.y-p1.y)/(p2.x-p1.x);
}

public double b(Point p1, Point p2){
	 return p1.y-(p2.y-p1.y)/(p2.x-p1.x)*p1.x;
}

public Point intersection(Line l1, Line l2){
	 double a1=a(l1.p1,l1.p2);
	 double b1=b(l1.p1,l1.p2);
	 double a2=a(l2.p1,l2.p2);
	 double b2=b(l2.p1,l2.p2);
	 double x=(b2-b1)/(a1-a2);
	 double y=a1*x+b1;
	 Point need=new Point(x,y);
	 return need;
}

public void insert(Line x){
//       if(this.line!=null){
//    	   
//       }
       if(this.line==null){
    	   this.line=x;
       }else{
    	   if(LineDirection(this.line,x)==1){
    		   if(leftChild==null){
    			   leftChild=new MyTreeNode<T>();                     
    			   leftChild.parent=this;
    		   }
    		   leftChild.insert(x);
    	   }
    	   if(LineDirection(this.line,x)==-1){
    		   if(rightChild==null){
    			   rightChild=new MyTreeNode<T>();
    			   rightChild.parent=this;
    		   }
    		   rightChild.insert(x);
    	   }
    	   if(LineDirection(this.line,x)==0){
    		   Point i=intersection(this.line,x);
    		   Line x1;
    		   Line x2;
    		   if(ccw(x.p1,this.line)==1){
    			   x1=new Line(x.p1,i,x.number);
    			   x2=new Line(i,x.p2,x.number);
    		   }else{
    			   x1=new Line(i,x.p2,x.number);
    			   x2=new Line(x.p1,i,x.number);
    		   }
    		   if(this.leftChild==null){
    			   this.leftChild=new MyTreeNode<T>();
    			   leftChild.parent=this;
    		   }
    		   leftChild.insert(x1);
    		   if(this.rightChild==null){
    			   rightChild=new MyTreeNode<T>();
    			   rightChild.parent=this;
    		   }
    		   rightChild.insert(x2);
    	   }
       }
		
    }

public MyTreeNode<T> Locate(Point p){
	if(this.line==null){
		return this;
	}else if(ccw(p,this.line)==1){
		if(this.leftChild==null){
			leftChild=new MyTreeNode<T>();
			leftChild.parent=this;
		}
		return leftChild.Locate(p);
	}else if(ccw(p,this.line)==-1){
		if(rightChild==null){
			rightChild=new MyTreeNode<T>();
			rightChild.parent=this;
		}
		return rightChild.Locate(p);
	}else{
		return null;
	}
}

public Line FindLine(Point a, Point b){
	if(this.line==null){
		return null;
	}else if(ccw(a,this.line)!=ccw(b,this.line)){
		return this.line;
	}else{
		if(ccw(a,this.line)==1){
			if(leftChild==null){
				return null;
			}else{
				return leftChild.FindLine(a, b);
			}
		}else if(ccw(a,this.line)==-1){
			if(rightChild==null){
				return null;
			}else{
				return rightChild.FindLine(a, b);
			}
		}else{
			return null;
		}
	}
}
    
    public void printInOrder() {
		// TODO Auto-generated method stub
		if(leftChild!=null){
			leftChild.printInOrder();
		}
		System.out.println(line.getLine());
		if(rightChild!=null){
			rightChild.printInOrder();
		}
	}
   

    
}
