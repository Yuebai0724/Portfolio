import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class PointLocation {
	public static ArrayList<Line> lines=new ArrayList<Line>();
	
 public int ccw(Point p0, Point p1, Point p2) {  
		int COUNTERCLOCKWISE=1;
		int CLOCKWISE=2;
		int COLINEAR=3;
		double dx1 = p1.x - p0.x;    
		double dy1 = p1.y - p0.y;    
		double dx2 = p2.x - p0.x;    
		double dy2 = p2.y - p0.y;    
		if (dx1*dy2 > dy1*dx2) return COUNTERCLOCKWISE;    
		else if (dx1*dy2 < dy1*dx2) return CLOCKWISE;    
		else if ((dx1*dx2 < 0) || (dy1*dy2 < 0)) return CLOCKWISE;    
		else if ((dx1*dx1+dy1*dy1) < (dx2*dx2+dy2*dy2)) return COUNTERCLOCKWISE;    
		else return COLINEAR; 
		
}
 
//y=ax+b
 
 public double a(Point p1, Point p2){
	 return (p2.y-p1.y)/(p2.x-p1.x);
 }
 
 public double b(Point p1, Point p2){
	 return p1.y-(p2.y-p1.y)/(p2.x-p1.x)*p1.x;
 }

 public Point intersection(Line l1, Line l2){
	 double a1=a(l1.p1,l1.p2);
	 double b1=b(l1.p1,l1.p2);
	 double a2=a(l2.p1,l2.p2);
	 double b2=b(l2.p1,l2.p2);
	 double x=(b2-b1)/(a1-a2);
	 double y=a1*x+b1;
	 Point need=new Point(x,y);
	 return need;
 }
 
 public int numberOfSpaces(Line[] lines){
	 int spacenumber=lines.length;
	 for(int i=0;i<lines.length;i++){
		 for(int j=0;j<lines.length && j!=i;j++){
			 Point intersect=intersection(lines[i],lines[j]);
			 if(0<=intersect.x && intersect.x<=1 && 0<=intersect.y && intersect.y<=1){
				 spacenumber++;
			 }
		 }
	 }
	 return spacenumber;
 }
 
	public static void main(String[] args){
		
		MyBinaryTree tree=new MyBinaryTree(null);
		
		Scanner scan=new Scanner(System.in);
		System.out.println("please enter the number of line");
		int n=scan.nextInt();
		
		for(int i=1;i<=n;i++){
			System.out.println("please enter x1 for line number"+i);
			double x1=scan.nextDouble();
			System.out.println("please enter y1 for line number"+i);
			double y1=scan.nextDouble();
			Point point1=new Point(x1,y1);
			
			System.out.println("please enter x2 for line number"+i);
			double x2=scan.nextDouble();
			System.out.println("please enter y2 for line number"+i);
			double y2=scan.nextDouble();
			Point point2=new Point(x2,y2);
			
			Line line=new Line(x1,y1,x2,y2,i);
			
			if(!(x1==0||x1==1||y1==0||y1==1||x2==0||x2==1||y2==1||y2==0)){
				System.out.println("please make sure at least one coordinate of each point is 1 or 0");
			}
			lines.add(line);
		}
		
		for(int i=0;i<lines.size();i++){
			System.out.println(lines.get(i).p1.x);
		}
		
		for(int i=0;i<lines.size();i++){
			tree.insert(lines.get(i));
		}
		tree.printInOrder();
		
		class Panel1 extends JPanel{
			@Override
			public void paintComponent(Graphics g){
				for(int n=0;n<lines.size();n++){
					g.drawLine((int)(lines.get(n).p1.x*300),(int)(300-lines.get(n).p1.y*300) ,(int) (lines.get(n).p2.x*300), (int)(300-lines.get(n).p2.y*300));
				}
			}
		}
		
		JFrame frame=new JFrame("Point Location");
		Panel1 panel=new Panel1();
		frame.add(panel);
		frame.setVisible(true);
		frame.setSize(300, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		System.out.println("enter x for the first point to locate");
		double m1=scan.nextDouble();
		System.out.println("enter y for the first point to locate");
		double n1=scan.nextDouble();
		System.out.println("enter x for the second point to locate");
		double m2=scan.nextDouble();
		System.out.println("enter y for the second point to locate");
		double n2=scan.nextDouble();
		Point point1=new Point(m1,n1);
		Point point2=new Point(m2,n2);
		
		if( tree.Locate(point1).equals(tree.Locate(point2)) ){
			System.out.println("The 2 points are in same space.");
		}else{
			System.out.println("The 2 points are not in same space.");
			System.out.println("The line that is between these 2 points: ");
			System.out.println(tree.FindLine(point1, point2).getLine());
		}
		
	}

}
