
public class MyBinaryTree<T extends Comparable<T>> implements BST<T>{

	MyTreeNode<T> root=null;
	
	
	public MyBinaryTree(Line data){
		root=new MyTreeNode<T>();
		root.line=data;
	}
	
	
	
	public Line FindLine(Point a, Point b){
		if(root==null){
			return null;
		}else{
			return root.FindLine(a, b);
		}
	}
	
	public MyTreeNode<T> Locate(Point p){
		if(root==null){
			return null;
		}else{
			return root.Locate(p);
		}
	}



	@Override
	public void insert(Line x) {
		// TODO Auto-generated method stub
		if(root==null){
			root.line=x;
		}else{
			root.insert(x);
		}
	}
	
	public void printInOrder(){
		root.printInOrder();
	}
	
}
