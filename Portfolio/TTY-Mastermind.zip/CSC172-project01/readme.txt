NAME: Yuebai Gao
E-MAIL: ygao41@u.rochester.edu
LAB SESSION: MW 1525-1640
Course: CSC 172
DATE: 2/18/2017

BREID DESCRIPTION OF THE PROJECT
1.This project is about designing code for MasterMind.
2.I only used one class"Test" for the whole project.
3.I used 4 major methods, including "permutation(to get all possibilities of colors)", response(to compare
colorsRightPositionWrong and PositionsColorsRight, delete the possibility as long as one of these two
numbers is different from the input; I use "comparePCR" to compute the PositionsColorsRight, "compareCRP"
to compute the colorsRightPositionWrong)
4.Although I wrote"The maximum number of colors is 5" since I am thinking about starting from the simplist
initially, there is basically no limit for the color number.
5.You can quit the game at the beginning or after every round.
6.When there is only one string in the "possibility" list, I treat it as the correct answer.
7.I print out all the posibilities left over after every guess and response to make it clearer.

The implementation provided further
All the methods are tested.