import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Test {
	static List<String[]> possibility=new ArrayList<String[]>();
	static List<String[]> create=new LinkedList<String[]>();
	
  
    public static void permutation(String[] output,String[] input, int positions){
    	String[] copy=new String[output.length];
    	if(positions==-1){
				for(int i=0;i<output.length;i++){ 
				   //System.out.print(output[i]);
				   copy[i]=output[i];
				}
				possibility.add(copy);
			}
			else{
				for(int i=0;i<input.length;i++){
					   output[positions]=input[i];
					   permutation(output,input,positions-1);
					}
			}
	}
 
	public static void response(String[] guess, int colorsRightPositionWrong, int positionsAndColorRight) {
//		System.out.println("the next guess: ");
//		print(guess);
		List<String[]> save=new LinkedList<String[]>();
		for(String[] list: possibility){
    	     if( !(comparePCR(guess,list)==positionsAndColorRight) || !(compareCRP(guess,list)==colorsRightPositionWrong)){
    	    	 //print(list);
    	    	 save.add(list);
    	     }
		}
		possibility.removeAll(save);
    }
	
	public static int comparePCR(String[] guess, String[] list){
    	int PCR=0;
			for(int j=0;j<guess.length;j++){
				   if(list[j].equals(guess[j])){
					    PCR++;
				   }
			}
			return PCR;
   }
	
	public static int compareCRP(String[] guess, String[] list){
		int CRP=0;
		int j=0;
		String[] guesscopy=new String[guess.length];
		for(int a=0;a<guess.length;a++){
			guesscopy[a]=guess[a];
		}
		
		String[] listcopy=new String[list.length];
		for(int a=0;a<guess.length;a++){
			listcopy[a]=list[a];
		}
			while(j<guesscopy.length){
				int i=0;
				while(i<guesscopy.length){
					if(list[j].equals(guess[j])){
						break;
					}
					else if(listcopy[j].equals(guesscopy[i]) && (i!=j) ){ //the element of the array is equal to another element of the guess with different positions
						  if((guesscopy[i]!=listcopy[i])){
			//the element of guess itself does not equal to the element in the array with same position
			                  guesscopy[i]="z";
			                  //listcopy[j]="z";
						     CRP++;
					         break;
						}
				   }
					i++;
				}
				j++;
			}
			return CRP;
   }

	
    public static void newGame() {
    	 for(int f=0;f<possibility.size();f++){
			  possibility.remove(f);
		  }
    }   // Reset the game 
    
    
    public static String [] nextMove() {
    	Random ran=new Random();
    	int result=ran.nextInt(possibility.size()-1);
    	String[] guess=new String[possibility.get(result).length];
    	for(int i=0;i<possibility.get(result).length;i++){
    		guess[i]=possibility.get(result)[i];
    	}
    	
    	return guess;
    }  // return the next guess
	
    
    public static void print(String[] need){
    	for(int i=0;i<need.length;i++){
    		System.out.print(need[i]);
    	}
    	System.out.println();
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
	while(true){
		Scanner scanner1=new Scanner(System.in);
		System.out.println("Do you want to start a new round?(quit by pressing 'quit', continue by pressing '1').");
		String game=scanner1.next();
		if(game.equals("quit")){
			System.out.println("Goodbye!");
			break;
		}
		System.out.println("New Game!");
		newGame(); //reset 'possibility'
        System.out.println("How many colors do you want to play with? (The maximum number of colors is 5.)");  
		Scanner scan=new Scanner(System.in);
		int colornumber=scan.nextInt();
		String[] tokencolor=new String[colornumber];
		
		int i=0;
		while(i<colornumber){
			System.out.println("enter the color: ");
			Scanner scanner=new Scanner(System.in);
			String color=scanner.nextLine();
			tokencolor[i]=color;
			i++;
		}
		
		System.out.println("How many positions you want to play with?");
		int positions=scan.nextInt();
		
		permutation(new String[positions],tokencolor,positions-1);
		
		for(int j=0;j<possibility.size();j++){     //print all possibilities
			  print(possibility.get(j));   
			  
		  }
		
		System.out.println("What is the secret colors?");
		String[] secret=new String[positions];
		for(int a=0;a<positions;a++){
			System.out.println("enter the secret color: ");
			String element=scan.next();
			secret[a]=element;
		}
		
		Random ran=new Random();
		int result=ran.nextInt(possibility.size()-1);
		String[] guess=new String[positions];
		for(int c=0;c<positions;c++){
			guess[c]=possibility.get(result)[c];
		}
		
		System.out.println("The guess is: ");
		print(guess);
		System.out.println();
		
		
		System.out.println("How many for colors right position wrong?");
		int colorsRightPositionWrong=scan.nextInt();
		
		System.out.println("How many for positions and colors right?");
		int positionsAndColorRight=scan.nextInt();
		
		
	  while(colorsRightPositionWrong!=0 || positionsAndColorRight!=positions ){
		
		  if(colorsRightPositionWrong==0 && positionsAndColorRight==positions){
			  System.out.println("The guess is right!!");
			  break;
		  }else{
//			  print(guess);
//			  System.out.println(colorsRightPositionWrong);
//			  System.out.println(positionsAndColorRight);
			  response(guess, colorsRightPositionWrong, positionsAndColorRight);
			  
		  }
		  
		  for(int j=0;j<possibility.size();j++){    //print all possibilities every time
			  print(possibility.get(j));
		  }
		  
		  if(possibility.size()==1){
			  System.out.println("The next guess(1) ");
			  print(possibility.get(0));
			  break;
		  }else {
		     System.out.println("The next guess is ");
		     String[] newguess=nextMove();
               print(newguess);
               
               for(int q=0;q<guess.length;q++){
            	   guess[q]=newguess[q];
               }
		  }
		  
          System.out.println("How many for colors right position wrong?");
    	  colorsRightPositionWrong=scan.nextInt();
    		
    	  System.out.println("How many for positions and colors right?");
    	  positionsAndColorRight=scan.nextInt(); 
            
	 }
	  System.out.println("The guess is right!");
	  
	}
	
	}

}
