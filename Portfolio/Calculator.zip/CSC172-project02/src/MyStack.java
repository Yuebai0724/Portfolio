
public class MyStack<AnyType> implements Stack<AnyType>{
	
	MyLinkedStack<AnyType> list=new MyLinkedStack<AnyType>();

	//problem 4
	@Override
	public boolean isEmpty() {
		//System.out.println("x");
		return list.isEmpty();
	}

	//problem 3
	@Override
	public void push(AnyType x) {
		// TODO Auto-generated method stub
		MyNode<AnyType> newnode=new MyNode<AnyType>();
		newnode.data=x;
		newnode.next=list.first;
		list.first=newnode;
		
	}
	

	//problem 4
	@Override
	public AnyType pop() {
		// TODO Auto-generated method stub
		MyNode node=list.first;
		if(list.isEmpty()==true){
			return null;
		}
		if(list.isEmpty()==false){
		   list.first=list.first.next;
		}
		return (AnyType) node.data;
		
	}

	//problem 5
	@Override
	public AnyType peek() {
		// TODO Auto-generated method stub
		MyNode node=list.first;
		
		return (AnyType) node.data;
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		 list.printList();
	}

}
