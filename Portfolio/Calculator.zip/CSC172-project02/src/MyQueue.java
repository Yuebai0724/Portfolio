
public class MyQueue<AnyType> implements Queue<AnyType>{

	MyLinkedQueue<AnyType> list = new MyLinkedQueue<AnyType>();

	@Override
	public void enqueue(AnyType x) {
		// TODO Auto-generated method stub
		list.insert(x);
	}
	
	@Override
	public AnyType dequeue() {
		// TODO Auto-generated method stub
		if(isEmpty()==true){
			return null;
		}else{
			MyDoubleNode first=list.head.next;
			list.head.next=first.next;
			return (AnyType) first.data;
		}
	}
	
	public void insertFront(AnyType x){
		MyDoubleNode<AnyType> newnode=new MyDoubleNode<AnyType>();
		newnode.data=x;
		MyDoubleNode first=list.head.next;
		newnode.next=first;
		newnode.prev=list.head;
		first.prev=newnode;
		list.head.next=newnode;
		newnode=first;
	}

	@Override
	public AnyType peek() {
		// TODO Auto-generated method stub
		if(isEmpty()==true) {
			return null;
		}
		else{
			MyDoubleNode first=list.head.next;
			return (AnyType) first.data;
		}
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return list.isEmpty();
	}
	
	@Override
	public void print(){
		// TODO Auto-generated method stub
		 list.printList();
	}

	

}
