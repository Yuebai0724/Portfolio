import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;

public class Calculator {
	
	public static int precedence(String operator){
		if(operator.equals("+")||operator.equals("-")){
			return 0;
		}else if(operator.equals("*")||operator.equals("/")){
			return 1;
		}else if(operator.equals("^")){
			return 2;
		}
		else if(operator.equals("(")){
			return -3;
		}else if(operator.equals("!")){
			return -1;
		}
		else if(operator.equals("<")||operator.equals(">")||operator.equals("=")||operator.equals("&")||operator.equals("|")){
			return -2;
		}
		return -1;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String[]> list=new ArrayList<String[]>();
		
	try{
		String filename="infix.txt";
		FileReader file=new FileReader((filename));
		BufferedReader readfile=new BufferedReader(file);
		String line=null;
		while((line=readfile.readLine())!=null){
			//System.out.println(line);
			String[] temp=line.split(" ");
			for(int i=0;i<temp.length;i++){
				
			}
			list.add(temp);
		}
		readfile.close();
	}catch(FileNotFoundException e){
		System.out.println("file not found");
	}catch(IOException e){
		System.out.println("error");
	}
	
//	for(int i=0;i<list.size();i++){
//		for(int j=0;j<list.get(i).length;j++){
//			System.out.print(list.get(i)[j]);
//		}
//		System.out.println();
//	}
	
	MyStack<String> operator=new MyStack<String>();
	MyQueue<String> output=new MyQueue<String>();
	LinkedList<MyQueue<String>> outputlist=new LinkedList<MyQueue<String>>();
	
	 for(int i=0;i<list.size();i++){
		for(int j=0;j<list.get(i).length;j++){
		
		  String element=list.get(i)[j];
		  //System.out.println(element);
			try{
				   Double number=Double.valueOf(element);
				   output.enqueue(element);
			 }catch(Exception e){
				   if(operator.isEmpty()){
					   operator.push(element);
					   //System.out.println(precedence(element));
				   }else{
					   if(element.equals("(")){
						   operator.push(element);
					   }
					   if(element.equals(")")){
						   //operator.pop();
						   //System.out.println(operator.peek());
						   while(!operator.peek().equals("(")){
						       output.enqueue(operator.pop());
					       }
						   operator.pop();
					   }
					   if(element.equals("^") && operator.peek().equals("^")){
						   operator.push(element);
					   }
					   else if(! (element.equals("(")|| element.equals(")"))){
					      if(precedence(operator.peek())<precedence(element)){
					         operator.push(element);
					     }else if(precedence(operator.peek())>=precedence(element)){
						    output.enqueue(operator.pop());
						    operator.push(element);
					     }
					   }
					   
				    }
			   
		  }
		
	}
        while(!operator.isEmpty()){
 	        output.enqueue(operator.pop());
 	        
        }
        MyQueue<String> copy=new MyQueue<String>();
        
        while(output.peek()!=null){ 
			   //System.out.print(output[i]);
			   copy.enqueue(output.dequeue());
		}
        //copy.print();
        outputlist.add(copy);
//        System.out.println("The output: ");
//        output.print();
       // System.out.println();
       
    }
//	    for(int i=0;i<outputlist.size();i++){
//			outputlist.get(i).print();
//			System.out.println();
//		}
	
	 Double[] finalresult=new Double[25];
	
	 for(int i=0;i<outputlist.size();i++){
	     MyQueue<String> thisqueue=outputlist.get(i);
	     //thisqueue.print();
	     MyStack<Double> thisstack=new MyStack<Double>(); //to store numbers
	     double c = 0;
	     while(thisqueue.isEmpty()==false){
	    	String question=thisqueue.peek();
	    	//System.out.println(question);
	    	
	    	try{
	    		double number=Double.valueOf(question);
	    		thisstack.push(number);
	    		thisqueue.dequeue();
	    		//thisstack.print();
	    	}catch(Exception e){
	    		if(question.equals("+")||question.equals("-")||question.equals("*")||question.equals("/")||question.equals("<")||question.equals(">")||question.equals("=")||question.equals("&")||question.equals("|")){
	    			double a= thisstack.pop();
	    			//System.out.println(a);
	    			double b= thisstack.pop();
	    			//System.out.println(b);
	    			
	    			if(question.equals("+")){
	    				c=b+a;
	    			}else if(question.equals("-")){
	    				c=b-a;
	    			}else if(question.equals("*")){
	    				c=b*a;
	    			}else if(question.equals("/")){
	    				c=b/a;
	    			}else if(question.equals("<")){
	    				if(b<a) c=1.0;
	    				else if(b>a) c=0.0;
	    			}else if(question.equals(">")){
	    				if(b>a) c=1.0;
	    				else if(b<a) c=0.0;
	    			}else if(question.equals("=")){
	    				if(b==a) c=1.0;
	    				else if(b!=a) c=0.0;
	    			}else if(question.equals("&")){
	    				if(a==1&&b==1) c=1.0;
	    				else c=0.0;
	    			}else if(question.equals("|")){
	    				if(a==1||b==1) c=1.0;
	    				else c=0.0;
	    			}
	    		
	    		}
	    		if(question.equals("!")){
	    			double d=thisstack.pop();
	    			if(d==1) c=0.0;
	    			else if(d==0) c=1.0;
	    		}
	    		    thisqueue.dequeue();   //delete the operator that we just compute
	    			thisstack.push(c);
	    			//System.out.println(c);
	    	}
	   }
	    //System.out.println(c);
	    finalresult[i]=c;
	 }
	 String stranswer="";
	for(int i=0;i<finalresult.length;i++){
		//System.out.println(finalresult[i]);
		stranswer=stranswer+finalresult[i].toString()+"\r\n";
	   
	}System.out.println(stranswer);
	try{
	  File answer=new File("result");
	  FileWriter writer=new FileWriter(answer);
	  writer.write(stranswer);
	  writer.close();
	}catch(IOException e){
		System.out.println("file not found");
	}
	
	}

	
}
