
public class MyDoubleNode<AnyType> { 
	 public AnyType data; 
	 public MyDoubleNode<AnyType> next; 
	 public MyDoubleNode<AnyType> prev; 
} 