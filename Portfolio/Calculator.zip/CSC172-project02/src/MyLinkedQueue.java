
public class MyLinkedQueue<AnyType> implements DoublyLinkedList<AnyType>{

	MyDoubleNode<AnyType> head;
	MyDoubleNode<AnyType> tail;
	
	public MyLinkedQueue(){
		head=new MyDoubleNode<AnyType>();
		tail=new MyDoubleNode<AnyType>();
		head.prev=null;
		tail.next=null;
		head.next=tail;
		tail.prev=head;
	}
	
	@Override
	public void insert(AnyType x) {
		MyDoubleNode<AnyType> newnode=new MyDoubleNode<AnyType>();
		newnode.data=x;
		
	    if(head.next==tail){
	    	head.next=newnode;
	    	newnode.next=tail;
	    	tail.prev=newnode;
	    	newnode.prev=head;
	    }
	    else {
	    	
	    	
	    	  MyDoubleNode last=tail.prev;
	          newnode.prev=last;
	          newnode.next=tail;
	          tail.prev=newnode;
	          last.next=newnode;
	    	
	    }
	    
	    
	}
	
	@Override
	public void delete(AnyType x) {
		// TODO Auto-generated method stub
		 for(MyDoubleNode<AnyType> i=head.next; i!=tail ;i=i.next){
			  if(i.data.equals(x)){
				 i.prev.next=i.next;
			  }
		   }	
		
		
	}

	@Override
	public boolean contains(AnyType x) {
		// TODO Auto-generated method stub

		   for(MyDoubleNode i=head.next; i!=tail ;i=i.next){
			  if(i.data.equals(x)){
				  return true;
			  }
		   }	
		return false;
	}

	@Override
	public AnyType lookup(AnyType x) {
		// TODO Auto-generated method stub
		
		for(MyDoubleNode i=head.next; i!=tail ;i=i.next){
			if(i.data.equals(x)){
				return x;
			}
		}	
		return null;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		if(head.next==tail){
		   return true;
		}
		return false;
	}

	//runtime: O(n)
	@Override
	public void printList() {
		// TODO Auto-generated method stub
		for(MyDoubleNode i=head.next; i!=tail ;i=i.next){
			System.out.print(i.data);
		}	
		
	}

	//runtime: O(n)
	@Override
	public void printListRev() {
		// TODO Auto-generated method stub
		for(MyDoubleNode i=tail.prev; i!=head;i=i.prev){
			System.out.println(i.data);
		}	
		
		
	}
	
	
	

}