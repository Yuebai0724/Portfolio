public class Test {
	
	public static int precedence(String operator){
		if(operator.equals("+")||operator.equals("-")){
			return 0;
		}else if(operator.equals("*")||operator.equals("/")){
			return 1;
		}else if(operator.equals("^")){
			return 2;
		}
		else if(operator.equals("(")){
			return -1;
		}
		return -1;
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try{
			Double number=Double.valueOf("5.2");
		}catch(Exception e){
			System.out.println("error");
		}
	}
}

