
public class MyLinkedStack<AnyType> implements SimpleLinkedList<AnyType>{
	protected MyNode first=null;
	
	//question 3:
	public boolean isEmpty(){
		if(first==null){
			return true;
		}else{
			return false;
		}
	}
	
	//question 3:
	//runtime: O(1)
	public void insert(AnyType x){
		MyNode<AnyType> newnode=new MyNode<AnyType>();
		newnode.data=x;
		MyNode last=null;
	
		if(first==null){
			first=newnode;
		}else{
			
			for(MyNode i=first; i!=null ;i=i.next){
			    last=i;
		    }
			last.next=newnode;
		}
	
	}

	
	//question 4:
	//runtime: O(n)
	@Override
	public void printList() {
		// TODO Auto-generated method stub
		for(MyNode i=first; i!=null ;i=i.next){
			System.out.println(i.data);
		}		
	}
		
	//question 7:
	@Override
	public void delete(AnyType x) {
		// TODO Auto-generated method stub

		if(first.data==x){
			 first=first.next;
			
		}else{
			
		  for(MyNode i=first; i.next!=null ;i=i.next){
			
			if(i.next.data.equals(x)&&i.next.next!=null){
				i.next=i.next.next;
			}else if(i.next.data.equals(x) && i.next.next==null){
				i.next=null;  //cannot execute i=i.next
				break;
			}
			
			
		  }
		}	
	}

	//question 5:
	@Override
	public boolean contains(AnyType x) {
		MyNode<AnyType> newnode=new MyNode<AnyType>();
		newnode.data=x;
		
		for(MyNode i=first; i!=null ;i=i.next){
			if(i.data==newnode.data){
				return true;
			}			
		}
		return false;		
	}

	//question 6:
	@Override
	public AnyType lookup(AnyType x) {
		MyNode<AnyType> newnode=new MyNode<AnyType>();
		newnode.data=x;
		for(MyNode i=first; i!=null ;i=i.next){
			if(i.data==newnode.data){
				return x;
			}
		}
		return null;	
	}
}
