
public class MyNode<AnyType> { 
	public AnyType data; 
	public MyNode<AnyType> next; 
}

