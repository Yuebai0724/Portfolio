NAME: Yuebai Gao
E-MAIL: ygao41@u.rochester.edu
LAB SESSION: MW 1525-1640
Course: CSC 172
DATE: 3/4/2017

BREID DESCRIPTION OF THE PROJECT
1.This project is about designing code for a Calculator.
2.I created the "txt" called "infix" to store infix. I read from this text in the code.
3.I first read from this text and store every line as a string array, using " " to split every element.
Then, I transform these infix into postfix then calculate them following the instructions on blackboard.
4.I print out all the results and store them in the file called "result" which is created
in the code I wrote.

The implementation provided further
All the methods are tested.